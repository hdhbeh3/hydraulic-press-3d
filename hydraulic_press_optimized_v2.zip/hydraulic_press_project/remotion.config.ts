import {Config} from '@remotion/cli/config';

const C: any = Config;
const set = (fn: string, ...args: any[]) => {
  try { C[fn]?.(...args); } catch { /* Keep compatible with Remotion 4.x patch releases. */ }
};

set('setVideoImageFormat', 'jpeg');
set('setJpegQuality', 90);
set('setCodec', 'h264');
set('setPixelFormat', 'yuv420p');
set('setCrf', 19);
set('setOverwriteOutput', true);
set('setChromiumOpenGlRenderer', 'angle');
set('setDelayRenderTimeoutInMilliseconds', 300000);
