import React from 'react';
import {AbsoluteFill, Audio, staticFile, useCurrentFrame, interpolate, Easing} from 'remotion';
import {Scene3D} from './World';

const clamp = {extrapolateLeft: 'clamp' as const, extrapolateRight: 'clamp' as const};
const sceneStarts = [0, 240, 360, 465, 585, 705, 900, 1110, 1395, 1665];
const sceneEnds   = [240, 360, 465, 585, 705, 900, 1110, 1395, 1665, 2115];

export const HydraulicPressVideo: React.FC = () => {
  const frame = useCurrentFrame();
  const idx = sceneStarts.findIndex((s, i) => frame >= s && frame < sceneEnds[i]);
  const scene = Math.max(0, idx);
  const start = sceneStarts[scene];
  const end = sceneEnds[scene];
  const p = interpolate(frame, [start, end], [0, 1], {...clamp, easing: Easing.inOut(Easing.cubic)});
  const fade = Math.min(1, interpolate(frame, [start, start + 14, end - 14, end], [0, 1, 1, 0], clamp));
  return (
    <AbsoluteFill style={{backgroundColor: '#111820'}}>
      <Scene3D scene={scene} progress={p} frame={frame} />
      <AbsoluteFill style={{background: `linear-gradient(180deg, rgba(3,8,14,${0.12 * fade}) 0%, transparent 24%, transparent 75%, rgba(3,8,14,${0.32 * fade}) 100%)`, pointerEvents: 'none'}} />
      <Audio src={staticFile('voiceover.m4a')} volume={1} />
      <Audio src={staticFile('audio/bed.wav')} volume={1} />
    </AbsoluteFill>
  );
};
