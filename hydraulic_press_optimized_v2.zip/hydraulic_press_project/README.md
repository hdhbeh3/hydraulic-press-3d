# Hydraulic Press — optimized Remotion project

A vertical 3D machine explainer built with Remotion 4, React Three Fiber and Three.js.

## Render specs
- Composition: `HydraulicPress`
- 1080 × 1920, 30 FPS, 2,115 frames (70.5 seconds)
- Original narration: `public/voiceover.m4a` (unchanged)
- Original background bed/SFX mix for this edit: `public/audio/bed.wav`
- Final output: `out/hydraulic_press_final.mp4`

## What changed for render efficiency
- Replaced the regular React Three Fiber `<Canvas>` with Remotion's `<ThreeCanvas>`, following the frame-driven structure used in the earlier TBM project.
- Camera is set deterministically from the current Remotion frame/progress instead of continuously easing toward a target with `useFrame`.
- Removed expensive real-time shadow rendering and reduced repeated cylinder tessellation from 48 to 24 segments (small decorative pieces use 10–16).
- Added JPEG frame rendering, H.264 settings and an explicit concurrency setting.
- Kept the scene timing, model parts, original voiceover and vertical composition duration.

These are render-efficiency changes, not a promise of a particular wall-clock render time. GitHub runner performance and WebGL backend still affect the result.

## Audio
`public/audio/bed.wav` contains a custom low-level cinematic music bed and synchronized hydraulic/mechanical SFX (pump hum, pressure hiss, metallic press impacts, valve clicks, return-flow hiss and scene-transition whooshes). It is ducked under the original narration. The original voiceover is not processed or replaced.

## GitHub Actions
The workflow in `.github/workflows/render.yml` has four modes:
- `stills`: four representative still frames at half scale
- `test`: first 90 frames (3 seconds) at final resolution; use this to measure render speed before committing to the full render
- `preview`: full-duration half-resolution preview
- `full`: final 1080×1920 MP4

If the project is being rendered from an uploaded ZIP, the repository's top-level workflow must first extract the ZIP and then run the selected mode from the extracted project directory. A workflow file stored inside a ZIP is not automatically registered by GitHub Actions until it is committed at `.github/workflows/render.yml` in the repository.

## Verification
This project has not been rendered in this workspace. The first GitHub Actions `test` run is the integration/speed check. Review its artifact before selecting `full`.
