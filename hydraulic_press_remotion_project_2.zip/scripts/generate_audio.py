"""Synthesises every sound effect and the background music locally (no downloads, no copyright issues)."""
import numpy as np, os
from scipy import signal
from scipy.io import wavfile

SR = 44100
rng = np.random.default_rng(7)
OUT = 'public/audio'; LIB = f'{OUT}/lib'
os.makedirs(LIB, exist_ok=True)

def t_(d): return np.arange(int(d * SR)) / SR
def norm(x, p=0.8): return x / (np.max(np.abs(x)) + 1e-9) * p
def band(x, lo, hi, o=2): return signal.sosfilt(signal.butter(o, [lo, hi], 'band', fs=SR, output='sos'), x)
def lp(x, fc, o=2): return signal.sosfilt(signal.butter(o, fc, 'low', fs=SR, output='sos'), x)
def hp(x, fc, o=2): return signal.sosfilt(signal.butter(o, fc, 'high', fs=SR, output='sos'), x)
def noise(d): return rng.standard_normal(int(d * SR))
def expd(t, k): return np.exp(-t * k)
def loopify(x, xf):
    n = len(x) - xf; y = x[:n].copy()
    f = np.linspace(0, 1, xf); y[:xf] = y[:xf] * f + x[n:] * (1 - f); return y
def save(name, x, stereo=False):
    x = np.clip(x, -1, 1); wavfile.write(f'{LIB}/{name}.wav' if not stereo else f'{OUT}/{name}.wav', SR, (x * 32767).astype(np.int16))

def plunger():
    t = t_(1.7); sweep = band(noise(1.7), 300, 1600) * (0.5 + 0.5 * np.sin(2 * np.pi * 11 * t))
    glug = np.sin(2 * np.pi * (140 + 90 * np.sin(2 * np.pi * 2.2 * t)) * t) * 0.4
    return norm((sweep + glug) * np.sin(np.pi * t / 1.7) ** 0.7)
def click():
    t = t_(0.16); return norm((band(noise(0.16), 1500, 6000) * expd(t, 70) + np.sin(2 * np.pi * 2200 * t) * expd(t, 55) * 0.5))
def check():
    t = t_(0.14); return norm(np.sin(2 * np.pi * 3300 * t) * expd(t, 60) + 0.4 * np.sin(2 * np.pi * 5100 * t) * expd(t, 90))
def stroke():
    t = t_(0.7)
    thump = np.sin(2 * np.pi * (95 - 45 * t / 0.7) * t) * expd(t, 9)
    hiss = hp(noise(0.7), 2500) * expd(t, 7) * 0.18
    clank = (np.sin(2 * np.pi * 820 * t) + 0.6 * np.sin(2 * np.pi * 1310 * t)) * expd(t, 28) * 0.35
    return norm(thump + hiss + clank)
def whoosh():
    t = t_(1.1); x = band(noise(1.1), 400, 3000) * 0.5 + band(noise(1.1), 1500, 7000) * np.sin(np.pi * t / 1.1) * 0.5
    return norm(x * np.sin(np.pi * t / 1.1) ** 1.5)
def thud():
    t = t_(0.8); return norm(np.sin(2 * np.pi * (75 - 35 * t) * t) * expd(t, 7) + lp(noise(0.8), 500) * expd(t, 25) * 0.5)
def ping():
    t = t_(1.0); return norm((np.sin(2 * np.pi * 880 * t) + 0.5 * np.sin(2 * np.pi * 1320 * t)) * expd(t, 4.5) * (1 - expd(t, 300)))
def bang():
    t = t_(0.7)
    res = sum(a * np.sin(2 * np.pi * f * t) * expd(t, k) for f, a, k in [(420, 1, 9), (780, 0.7, 12), (1450, 0.5, 18)])
    return norm(res + band(noise(0.7), 800, 6000) * expd(t, 35))
def crush():
    d = 6.2; t = t_(d); out = np.zeros_like(t)
    groan = np.sin(2 * np.pi * (45 + 14 * t / d) * t + 3 * np.sin(2 * np.pi * 1.7 * t)) * np.minimum(t / 3, 1) * 0.5
    out += groan
    creak = band(noise(d), 700, 1300, 3) * (0.5 + 0.5 * np.sin(2 * np.pi * (3 + t) * t)) ** 3 * 0.55
    out += creak
    for ts in np.sort(rng.uniform(0.2, 5.4, 16)):
        n = int(0.28 * SR); i = int(ts * SR); tt = np.arange(n) / SR
        out[i:i + n] += band(noise(0.28), 500, 3500) * expd(tt, 18) * rng.uniform(0.4, 1.0)
    return norm(out)
def valve_turn():
    d = 2.0; t = t_(d); out = band(noise(d), 200, 900) * 0.12 * np.minimum(t / 0.2, 1)
    for ts in np.arange(0.1, d - 0.1, 0.13):
        i = int(ts * SR); n = int(0.03 * SR); out[i:i + n] += np.sin(2 * np.pi * 2600 * np.arange(n) / SR) * expd(np.arange(n) / SR, 160) * 0.8
    return norm(out)
def hiss():
    t = t_(2.6); return norm(hp(noise(2.6), 2800) * (expd(t, 1.6) * (1 - expd(t, 40))))
def strain():
    t = t_(1.8); f = 120 + 140 * (t / 1.8) ** 2
    return norm((np.sin(2 * np.pi * np.cumsum(f) / SR) + 0.5 * np.sin(4 * np.pi * np.cumsum(f) / SR)) * np.sin(np.pi * t / 1.8) ** 2 * 0.7 + band(noise(1.8), 600, 1500) * 0.15)
def spring():
    t = t_(1.2); return norm(sum(np.sin(2 * np.pi * f * t + 4 * expd(t, 5) * np.sin(2 * np.pi * 7 * t)) * expd(t, k) for f, k in [(310, 4), (620, 6), (1240, 9)]))
def hum_loop():
    d = 3.0; t = t_(d); x = np.sin(2 * np.pi * 54 * t) + 0.6 * np.sin(2 * np.pi * 108 * t) + 0.3 * np.sin(2 * np.pi * 162 * t)
    return norm(x + loopify(lp(noise(d + 0.4), 700), int(0.4 * SR))[: len(t)] * 0.25)
def flow_loop():
    d = 4.0; x = band(noise(d + 0.5), 400, 2600) * (0.6 + 0.4 * lp(noise(d + 0.5), 8)) ; return norm(loopify(x, int(0.5 * SR)))
def splash_loop():
    d = 4.0; x = band(noise(d + 0.5), 500, 3500) * 0.5
    for ts in rng.uniform(0, d, 70):
        i = int(ts * SR); n = int(0.05 * SR); tt = np.arange(n) / SR
        if i + n < len(x): x[i:i + n] += np.sin(2 * np.pi * rng.uniform(500, 1800) * tt) * expd(tt, 60) * 0.6
    return norm(loopify(x, int(0.5 * SR)))

for name, fn in dict(plunger=plunger, click=click, check=check, stroke=stroke, whoosh=whoosh, thud=thud, ping=ping, bang=bang,
                     crush=crush, valve_turn=valve_turn, hiss=hiss, strain=strain, spring=spring, hum_loop=hum_loop,
                     flow_loop=flow_loop, splash_loop=splash_loop).items():
    save(name, fn())

def music(d=72.0):
    t = t_(d); L = np.zeros_like(t); R = np.zeros_like(t)
    chords = [(110.0, 130.8, 164.8), (87.3, 110.0, 130.8), (130.8, 164.8, 196.0), (98.0, 123.5, 146.8)]
    seg = 8.0
    for k in range(int(d / seg) + 1):
        ch = chords[k % 4]; i0 = int(k * seg * SR); i1 = min(len(t), int((k + 1) * seg * SR + 1.5 * SR))
        if i0 >= len(t): break
        tt = t[i0:i1] - k * seg; a = np.minimum(tt / 1.5, 1) * np.clip((seg + 1.5 - tt) / 1.5, 0, 1)
        for j, f in enumerate(ch):
            for det, side in ((-0.4, 0), (0.4, 1)):
                w = sum(np.sin(2 * np.pi * f * (1 + det * 0.004) * h * tt + j) / h for h in (1, 2, 3, 4))
                (L if side == 0 else R)[i0:i1] += w * a * 0.12
        sub = np.sin(2 * np.pi * ch[0] / 2 * tt) * a * 0.22; L[i0:i1] += sub; R[i0:i1] += sub
        for b in range(16):  # soft arpeggio bells
            tb = b * 0.5
            if tb + 0.6 > len(tt) / SR: break
            n = int(1.2 * SR); i = int(tb * SR); f = ch[b % 3] * 4; tn = np.arange(n) / SR
            bell = np.sin(2 * np.pi * f * tn) * expd(tn, 3.5) * 0.05
            j0 = i0 + i; j1 = min(len(t), j0 + n)
            L[j0:j1] += bell[: j1 - j0] * (0.6 + 0.4 * (b % 2)); R[j0:j1] += bell[: j1 - j0] * (1.0 - 0.4 * (b % 2))
    L, R = lp(L, 2200), lp(R, 2200)
    m = np.max(np.abs(np.stack([L, R]))); return L / m * 0.6, R / m * 0.6
L, R = music()
wavfile.write(f'{OUT}/music.wav', SR, (np.stack([L, R], 1) * 32767).astype(np.int16))
print('generated', len(os.listdir(LIB)), 'library sounds + music.wav')
