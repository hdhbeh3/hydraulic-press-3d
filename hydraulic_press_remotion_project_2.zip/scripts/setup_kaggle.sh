#!/usr/bin/env bash
# Run once in a Kaggle notebook cell:  !bash scripts/setup_kaggle.sh && !npm run render
set -e
apt-get update -y
apt-get install -y ffmpeg libnss3 libdbus-1-3 libatk1.0-0 libgbm-dev libasound2 libxrandr2 libxkbcommon-dev libxfixes3 libxcomposite1 libxdamage1 libatk-bridge2.0-0 libcups2 libpango-1.0-0 libcairo2 libgl1 libgles2
if ! command -v node >/dev/null || [ "$(node -v | cut -d. -f1 | tr -d v)" -lt 18 ]; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
fi
npm install --no-audit --no-fund
npm test
echo "Ready. Render with: npm run render   (output: out/hydraulic_press_final.mp4)"
