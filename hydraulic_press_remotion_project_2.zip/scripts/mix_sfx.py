"""Builds public/audio/sfx_bed.wav: every SFX placed at its timeline time + motion-driven loops."""
import json, numpy as np
from scipy.io import wavfile
SR = 44100
tl = json.load(open('build/timeline.json'))
dur = tl['frames'] / tl['fps']; N = int(np.ceil(dur * SR)) + SR // 2
bed = np.zeros(N); pan = np.zeros((N, 2))
cache = {}
SFX_SCALE = 0.70  # global SFX reduction (-30%) applied to every timeline event
def lib(n):
    if n not in cache:
        sr, x = wavfile.read(f'public/audio/lib/{n}.wav'); assert sr == SR; cache[n] = x.astype(np.float64) / 32768
    return cache[n]
L = np.zeros(N); R = np.zeros(N)
for e in tl['events']:
    x = lib(e['file']) * e['vol'] * SFX_SCALE; i = int(e['t'] * SR); n = min(len(x), N - i)
    p = 0.5
    if e['file'] == 'whoosh': p = 0.5 + 0.35 * np.sin(e['t'])  # slight stereo movement
    L[i:i + n] += x[:n] * np.sqrt(1 - p); R[i:i + n] += x[:n] * np.sqrt(p)
def loop(name, gains, vol):
    x = lib(name); y = np.tile(x, int(np.ceil(N / len(x))))[:N]
    g = np.interp(np.arange(N) / SR, np.arange(len(gains)) / tl['fps'], gains)
    g = np.convolve(g, np.ones(2205) / 2205, 'same')  # de-click
    return y * g * vol
for name, key, vol in (('hum_loop', 'hum', 0.154), ('flow_loop', 'flow', 0.21), ('splash_loop', 'splash', 0.21)):
    y = loop(name, tl[key], vol); L += y; R += y
pk = max(np.max(np.abs(L)), np.max(np.abs(R)))
if pk > 0.95: L, R = L / pk * 0.95, R / pk * 0.95
wavfile.write('public/audio/sfx_bed.wav', SR, (np.stack([L, R], 1) * 32767).astype(np.int16))
print(f'sfx_bed.wav {N/SR:.2f}s peak {pk:.2f}')
