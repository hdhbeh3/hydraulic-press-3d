import {readFileSync, existsSync} from 'node:fs';
import {DURATION_FRAMES, FPS, SCENES, DURATION_SEC} from '../src/constants';
import {getState, buildSfx} from '../src/timeline';
import {cameraAt} from '../src/camera';

let fail = 0;
const ok = (c: boolean, m: string) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) fail++; };

ok(DURATION_FRAMES === 2115, `duration frames = ${DURATION_FRAMES} (70.493 s @ ${FPS} fps)`);
ok(SCENES[0].start === 0 && Math.abs(SCENES[9].end - DURATION_SEC) < 1e-9, 'scenes cover whole timeline');
for (let i = 1; i < SCENES.length; i++) if (SCENES[i].start !== SCENES[i - 1].end) { ok(false, 'scene gap at ' + i); }

const finite = (o: any): boolean => typeof o === 'number' ? Number.isFinite(o) : typeof o === 'object' && o ? Object.values(o).every(finite) : true;
let allFinite = true, maxCam = 0, maxCamF = 0, maxTgt = 0, maxTgtF = 0, prevRam = 0, monoBad = 0, prevCam: any = null;
for (let f = 0; f < DURATION_FRAMES; f++) {
  const t = f / FPS;
  const s = getState(t);
  if (!finite(s)) allFinite = false;
  if ((t < 52 && t > 31) && s.ram < prevRam - 1e-6) monoBad++;
  prevRam = s.ram;
  const c = cameraAt(t);
  if (!finite(c)) allFinite = false;
  if (prevCam) {
    const d = Math.hypot(...c.pos.map((v, i) => v - prevCam.pos[i]));
    const g = Math.hypot(...c.target.map((v, i) => v - prevCam.target[i]));
    if (d > maxCam) { maxCam = d; maxCamF = f; }
    if (g > maxTgt) { maxTgt = g; maxTgtF = f; }
  }
  prevCam = c;
}
ok(allFinite, 'all animation + camera values finite on every frame');
ok(monoBad === 0, 'ram never retreats during descent/crush');
console.log(`  max camera step ${maxCam.toFixed(2)} units/frame @ frame ${maxCamF}; target ${maxTgt.toFixed(2)} @ ${maxTgtF}`);
ok(maxCam < 2.6 && maxTgt < 1.0, 'camera motion has no jumps');
const s0 = getState(0), sEnd = getState(DURATION_SEC);
ok(s0.ram === 0 && sEnd.ram > 0.99, 'ram starts retracted, ends pressed');
ok(getState(54).P > 0.95 && getState(60).P < 0.05, 'pressure holds at crush, drops after release valve opens');
ok(getState(53).work > 0.99 && getState(63).work > 0.9, 'steel stays crushed after release (plastic deformation)');
const sfx = buildSfx();
ok(sfx.length > 40 && sfx.every((e) => e.t >= 0 && e.t < DURATION_SEC && e.vol > 0 && e.vol <= 1), `${sfx.length} SFX events inside timeline`);
const env = JSON.parse(readFileSync('src/data/voiceover_envelope.json', 'utf8'));
ok(!existsSync('src/data/voiceover_envelope.json') || env.length === DURATION_FRAMES, `voiceover envelope has ${env.length} frames`);
process.exit(fail ? 1 : 0);
