"""Simulates the Remotion mix (same gains/ducking) and checks the voiceover stays dominant."""
import json, subprocess, re, numpy as np
from scipy.io import wavfile
SR = 44100
const = open('src/constants.ts').read()
g = lambda k: float(re.search(rf'{k}:\s*([\d.]+)', const).group(1))
MIX = dict(vo=g('voiceover'), music=g('music'), sfx=g('sfx'), duck=g('duckAmount'))
subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', 'public/audio/voiceover.m4a', '-ar', str(SR), '-ac', '1', '/tmp/vo44.wav'], check=True)
_, vo = wavfile.read('/tmp/vo44.wav'); vo = vo.astype(float) / 32768 * MIX['vo']
_, mu = wavfile.read('public/audio/music.wav'); mu = mu.astype(float).mean(1) / 32768
_, sf = wavfile.read('public/audio/sfx_bed.wav'); sf = sf.astype(float).mean(1) / 32768
env = np.array(json.load(open('src/data/voiceover_envelope.json')))
n = len(vo); tt = np.arange(n) / SR
duck = 1 - MIX['duck'] * np.interp(tt * 30, np.arange(len(env)), env)
fade = np.minimum(1, tt / 1.5) * np.minimum(1, (70.5 - tt) / 2)
music = mu[:n] * MIX['music'] * duck * fade; sfx = sf[:n] * MIX['sfx'] * duck
mix = vo + music + sfx
db = lambda x: 20 * np.log10(np.sqrt(np.mean(x ** 2)) + 1e-9)
speech = np.interp(tt * 30, np.arange(len(env)), env) > 0.5
print(f'voiceover  RMS {db(vo[speech]):6.1f} dBFS (speaking)')
print(f'music      RMS {db(music[speech]):6.1f} dBFS  -> {db(vo[speech]) - db(music[speech]):.1f} dB below voice')
print(f'sfx        RMS {db(sfx[speech]):6.1f} dBFS  -> {db(vo[speech]) - db(sfx[speech]):.1f} dB below voice')
print(f'mix peak {np.max(np.abs(mix)):.2f}  (voiceover alone peak {np.max(np.abs(vo)):.2f}), duration {n/SR:.3f}s')
assert db(music[speech]) < db(vo[speech]) - 12, 'music too loud'
assert db(sfx[speech]) < db(vo[speech]) - 8, 'sfx too loud'
print('MIX OK: voiceover dominant')
