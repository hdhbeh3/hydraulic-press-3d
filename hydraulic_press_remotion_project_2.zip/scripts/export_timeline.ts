// Exports the SFX schedule + continuous-sound gain curves from src/timeline.ts so the
// audio bed is generated from the exact same data that drives the animation.
import {writeFileSync, mkdirSync} from 'node:fs';
import {FPS, DURATION_FRAMES} from '../src/constants';
import {getState, buildSfx} from '../src/timeline';
import {clamp} from '../src/math';

const hum: number[] = [], flow: number[] = [], splash: number[] = [];
for (let f = 0; f < DURATION_FRAMES; f++) {
  const s = getState(f / FPS);
  hum.push(+clamp(Math.abs(s.vel) * 12).toFixed(3));
  flow.push(+clamp(Math.max(s.rig.flow, s.hoseFlow * 0.8, s.pump.env * 0.35)).toFixed(3));
  splash.push(+clamp(s.valve * (s.ram > 0.02 ? 1 : 0.3)).toFixed(3));
}
mkdirSync('build', {recursive: true});
writeFileSync('build/timeline.json', JSON.stringify({fps: FPS, frames: DURATION_FRAMES, events: buildSfx(), hum, flow, splash}));
console.log('exported', buildSfx().length, 'events');
