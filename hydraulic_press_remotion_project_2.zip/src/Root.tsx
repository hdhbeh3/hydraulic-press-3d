import React from 'react';
import {Composition} from 'remotion';
import {HydraulicPress, HydraulicPressSafeZones} from './HydraulicPress';
import {DURATION_FRAMES, FPS, HEIGHT, WIDTH} from './constants';

export const RemotionRoot: React.FC = () => (
  <>
    <Composition id="HydraulicPress" component={HydraulicPress} durationInFrames={DURATION_FRAMES} fps={FPS} width={WIDTH} height={HEIGHT} />
    <Composition id="HydraulicPressSafeZones" component={HydraulicPressSafeZones} durationInFrames={DURATION_FRAMES} fps={FPS} width={WIDTH} height={HEIGHT} />
  </>
);
