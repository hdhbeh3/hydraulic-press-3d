// All animation channels as pure functions of time (seconds). No React/three imports,
// so this file is unit-testable in plain Node and also drives the audio export.
import {clamp, lerp, ramp, pw, smoothedPw, Keys} from './math';
import {DURATION_SEC} from './constants';
import {CONTACT, billetHeight, plateBottomFromRam, BED_Y} from './geometry';
import {BANG_TIMES} from './camera';

export const LEVER_HZ = 1.1;
const TAU = Math.PI * 2;

export const pumpEnv = (t: number) =>
  ramp(t, 28.0, 28.8) * (1 - ramp(t, 53.6, 54.4)) + ramp(t, 64.5, 65.0) * (1 - ramp(t, 68.3, 69.0));

// ---- master ram position (0 = retracted, 1 = fully pressed) -------------------------------
const RAM_KEYS: Keys = [
  [0, 0], [31, 0], [36.9, 0.04], [42.14, 0.34], [46.6, CONTACT], [52.0, 1], [57.4, 1],
  [62.8, 0], [64.4, 0], [69.0, 1], [71, 1],
];
export const ram = (t: number) => clamp(smoothedPw(t, RAM_KEYS, 1.0));
const ramVel = (t: number) => (ram(t + 0.05) - ram(t - 0.05)) / 0.1;

const P_KEYS: Keys = [
  [0, 0], [28.4, 0], [30, 0.16], [42, 0.24], [46.6, 0.34], [52.0, 1], [55.9, 1], [58.2, 0.02],
  [63.6, 0], [64.6, 0.1], [69.0, 1], [71, 1],
];

// cumulative pumped volume tables (numeric integral of the lever motion)
function buildTable(fn: (t: number) => number, dt = 1 / 240, T = 72) {
  const n = Math.ceil(T / dt);
  const a = new Float32Array(n + 1);
  let s = 0;
  for (let i = 1; i <= n; i++) {
    s += fn((i - 0.5) * dt) * dt;
    a[i] = s;
  }
  return {a, dt};
}
const look = (tb: {a: Float32Array; dt: number}, t: number) => {
  const x = clamp(t, 0, 71.9) / tb.dt;
  const i = Math.min(tb.a.length - 2, Math.floor(x));
  return lerp(tb.a[i], tb.a[i + 1], x - i);
};
const SUC = buildTable((t) => pumpEnv(t) * Math.max(Math.cos(TAU * LEVER_HZ * t), 0) * TAU * LEVER_HZ);
const DIS = buildTable((t) => pumpEnv(t) * Math.max(-Math.cos(TAU * LEVER_HZ * t), 0) * TAU * LEVER_HZ);

export const HOSE_K = 1.6; // hose lengths of oil per full ram stroke (stylised, keeps motion readable)

export function getState(t: number) {
  // ---- 1 syringe ------------------------------------------------------------------------
  const fill = 0.1 + 0.85 * ramp(t, 0.9, 2.5) - 0.5 * ramp(t, 2.9, 4.3);
  const lift = 2.0 * ramp(t, 4.4, 5.2);
  const cap = ramp(t, 5.3, 5.9);
  const press1 = ramp(t, 6.1, 6.7) * (1 - ramp(t, 7.2, 7.7));
  const glass = 1.55 - (0.5 * clamp((fill - 0.1) / 0.85));

  // ---- 2/3 connected syringes -------------------------------------------------------------
  const pushOf = (x: number) => 0.5 * ramp(x, 9.0, 13.2) + 0.5 * ramp(x, 16.0, 18.8);
  const push = pushOf(t);
  const pushVel = (pushOf(t + 0.05) - pushOf(t - 0.05)) / 0.1;
  const arrows = ramp(t, 12.0, 12.8) * (1 - ramp(t, 19.0, 19.5));
  const wt = (t - 14.9) / 0.5;
  const weight = {
    visible: t >= 14.9,
    dy: t < 14.9 ? 7 : 7 * Math.pow(1 - clamp(wt), 2) + (t > 15.4 ? 0.07 * Math.exp(-(t - 15.4) * 8) * Math.cos((t - 15.4) * 30) : 0),
  };

  // ---- 4 Pascal ---------------------------------------------------------------------------
  const P4 = smoothedPw(t, [[0, 0], [21, 0], [22.6, 0.55], [24.4, 0.55], [25.8, 1], [60, 1]] as Keys, 0.4);
  const pascal = {P: clamp(P4), push: 0.25 * ramp(t, 21.0, 22.6) + 0.15 * ramp(t, 24.4, 25.8)};

  // ---- pump lever --------------------------------------------------------------------------
  const env = pumpEnv(t);
  const p = env * Math.sin(TAU * LEVER_HZ * t);
  const c = env * Math.cos(TAU * LEVER_HZ * t);
  const pump = {
    env, p, c,
    theta: Math.asin(0.25 * p),
    inlet: clamp(c * 3), // suction stroke: inlet check ball lifts
    outlet: clamp(-c * 3), // discharge stroke: outlet check ball lifts
    sucPhase: look(SUC, t) * 0.15,
    disPhase: look(DIS, t) * 0.5,
  };

  // ---- press ------------------------------------------------------------------------------
  const r = ram(t);
  const vel = ramVel(t);
  const valve = clamp(ramp(t, 56.0, 58.0) - ramp(t, 62.9, 63.6), 0, 1);
  const ripple = 0.012 * env * Math.sin(TAU * LEVER_HZ * t);
  const P = clamp(smoothedPw(t, P_KEYS, 0.6) + (smoothedPw(t, P_KEYS, 0.6) > 0.1 ? ripple : 0));

  // billet deformation (plastic: it stays crushed after release, with a little springback)
  const raw = (x: number) => clamp((x - CONTACT) / (1 - CONTACT));
  let work: number;
  if (t < 57.2) work = raw(r);
  else if (t < 64) work = 1 - 0.03 * ramp(t, 57.6, 60);
  else work = Math.max(0.97, raw(r));
  const plateBottom = Math.max(plateBottomFromRam(r), BED_Y + billetHeight(work));

  const cut = {
    tank: clamp(ramp(t, 27.8, 28.8) * (1 - ramp(t, 35.4, 36.6)) + ramp(t, 56.6, 57.4) * (1 - ramp(t, 62.4, 63.2)) + 0.55 * ramp(t, 63.6, 64.4)),
    pump: clamp(ramp(t, 28.8, 29.8) * (1 - ramp(t, 35.8, 36.6)) + 0.5 * ramp(t, 63.6, 64.4)),
    valve: clamp(ramp(t, 54.6, 55.4) * (1 - ramp(t, 59.6, 60.4)) + 0.5 * ramp(t, 63.6, 64.4)),
    hose: clamp(ramp(t, 35.4, 36.4) * (1 - ramp(t, 38.8, 39.8)) + ramp(t, 59.2, 60.0) * (1 - ramp(t, 62.8, 63.5)) + 0.5 * ramp(t, 63.6, 64.4)),
    cyl: clamp(ramp(t, 37.2, 38.2) * (1 - ramp(t, 42.2, 43.2)) + ramp(t, 60.0, 60.8) * (1 - ramp(t, 62.8, 63.5)) + 0.6 * ramp(t, 63.6, 64.4)),
  };

  return {
    t, s1: {fill, lift, cap, press: press1, glass},
    rig: {push, flow: clamp(Math.abs(pushVel) / 0.1), arrows, weight},
    pascal, pump,
    ram: r, vel, P, valve, work, plateBottom, cut,
    tankLevel: 1.9 - 0.35 * r,
    phase: {rig: push * 2.4, hose: r * HOSE_K, ret: -r * HOSE_K * 3},
    hoseFlow: clamp(Math.abs(vel) * 14),
  };
}
export type State = ReturnType<typeof getState>;

// ---- audio events (consumed by scripts/export_timeline.ts -> mix_sfx.py) ----------------------
export interface Sfx { t: number; file: string; vol: number }
export function buildSfx(): Sfx[] {
  const e: Sfx[] = [];
  const add = (t: number, file: string, vol: number) => e.push({t, file, vol});
  [[7.5, 0.45], [19.2, 0.4], [25.9, 0.7], [36.2, 0.4], [54.1, 0.6], [63.0, 0.5], [67.9, 0.35]].forEach(([t, v]) => add(t, 'whoosh', v));
  add(0.8, 'plunger', 0.55); add(2.8, 'plunger', 0.5);
  add(5.85, 'click', 0.7); add(6.0, 'strain', 0.45);
  add(15.35, 'thud', 0.8);
  add(21.5, 'ping', 0.5); add(25.3, 'ping', 0.5);
  // lever strokes: one chug at the top of every stroke, valve ticks on the first strokes
  for (const [a, b] of [[28.4, 54.0], [64.6, 68.6]]) {
    for (let k = Math.ceil(a * LEVER_HZ - 0.25); ; k++) {
      const ts = (k + 0.25) / LEVER_HZ;
      if (ts > b) break;
      if (ts >= a) add(ts, 'stroke', pumpEnv(ts) * 0.5);
    }
  }
  for (let k = 0; ; k++) {
    const ts = (0.25 + k * 0.5) / LEVER_HZ;
    if (ts > 33) break;
    if (ts >= 29.0) add(ts, 'check', 0.35);
  }
  add(46.6, 'thud', 0.7); add(46.6, 'crush', 0.85);
  [47.6, 49.5, 51.3].forEach((b, i) => add(b, 'bang', 0.5 + 0.05 * i));
  add(52.3, 'bang', 0.5);
  add(56.05, 'valve_turn', 0.7); add(57.6, 'hiss', 0.6); add(57.5, 'spring', 0.45);
  add(62.8, 'thud', 0.4); add(62.9, 'valve_turn', 0.4);
  add(69.0, 'ping', 0.4);
  return e.filter((x) => x.t >= 0 && x.t < DURATION_SEC).sort((a, b) => a.t - b.t);
}

export const BANGS = BANG_TIMES;
