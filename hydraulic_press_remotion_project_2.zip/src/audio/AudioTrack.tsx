import React from 'react';
import {Audio, staticFile} from 'remotion';
import env from '../data/voiceover_envelope.json';
import {MIX, DURATION_FRAMES, FPS} from '../constants';

const speech = env as number[];
/** music and SFX dip while the narrator speaks, so the voiceover is always on top */
const duck = (f: number) => 1 - MIX.duckAmount * (speech[Math.min(Math.max(Math.round(f), 0), speech.length - 1)] ?? 0);

export const AudioTrack: React.FC = () => (
  <>
    {/* original voiceover — untouched file, full level */}
    <Audio src={staticFile('audio/voiceover.m4a')} volume={MIX.voiceover} />
    <Audio
      src={staticFile('audio/music.wav')}
      volume={(f) => {
        const fadeIn = Math.min(1, f / (1.5 * FPS));
        const fadeOut = Math.min(1, (DURATION_FRAMES - f) / (2 * FPS));
        return MIX.music * duck(f) * fadeIn * fadeOut;
      }}
    />
    <Audio src={staticFile('audio/sfx_bed.wav')} volume={(f) => MIX.sfx * duck(f)} />
  </>
);
