import React, {useLayoutEffect, useMemo} from 'react';
import * as THREE from 'three';
import {useThree} from '@react-three/fiber';
import {RoomEnvironment} from 'three/examples/jsm/environments/RoomEnvironment.js';
import {getMats} from '../materials';
import {mulberry32} from '../math';

/** Procedural reflection probe (no external HDRI -> fully offline). */
export const EnvMap: React.FC = () => {
  const {gl, scene} = useThree();
  useLayoutEffect(() => {
    const pm = new THREE.PMREMGenerator(gl);
    const env = pm.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = env;
    scene.background = new THREE.Color('#93abc0');
    scene.fog = new THREE.Fog('#a9bccb', 55, 140);
    return () => { scene.environment = null; env.dispose(); pm.dispose(); };
  }, [gl, scene]);
  return null;
};

/** Shop yard in front of a brick building (mirrors the reference's everyday-garden look). */
export const Backdrop: React.FC = () => {
  const M = getMats();
  const hedges = useMemo(() => { const r = mulberry32(8); return Array.from({length: 26}, (_, i) => ({x: -62 + i * 4.9 + r() * 1.5, s: 3.2 + r() * 1.8, h: 1.2 + r() * 0.9})); }, []);
  const wins = useMemo(() => Array.from({length: 11}, (_, i) => -55 + i * 11), []);
  return (
    <group>
      <mesh rotation={[-Math.PI / 2, 0, 0]} material={M.grass} receiveShadow><planeGeometry args={[320, 320]} /></mesh>
      <mesh position={[3.5, 0.05, 0]} material={M.concrete} receiveShadow><boxGeometry args={[28, 0.1, 13]} /></mesh>
      <mesh position={[0, 15, -16]} material={M.brick} receiveShadow><boxGeometry args={[150, 30, 1]} /></mesh>
      <mesh position={[0, 1.0, -15.4]} material={M.stone} castShadow><boxGeometry args={[150, 2, 0.6]} /></mesh>
      {wins.map((x) => (
        <group key={x} position={[x, 11.5, -15.4]}>
          <mesh material={M.stone}><boxGeometry args={[5.2, 8.8, 0.4]} /></mesh>
          <mesh position={[0, 0, 0.12]} material={M.windowGlass}><boxGeometry args={[4.3, 7.9, 0.2]} /></mesh>
          <mesh position={[0, 0, 0.26]} material={M.stone}><boxGeometry args={[0.15, 7.9, 0.1]} /></mesh>
          <mesh position={[0, 0.5, 0.26]} material={M.stone}><boxGeometry args={[4.3, 0.15, 0.1]} /></mesh>
          <mesh position={[0, -4.6, 0.25]} material={M.stone}><boxGeometry args={[5.8, 0.4, 0.9]} /></mesh>
        </group>
      ))}
      {hedges.map((h, i) => (
        <mesh key={i} position={[h.x, h.h * 0.6, -13.2]} scale={[h.s, h.h, 1.9]} material={M.hedge} castShadow><sphereGeometry args={[1, 14, 10]} /></mesh>
      ))}
    </group>
  );
};

/** Wooden café table that carries the syringe demonstrations (top surface y = 3). */
export const CafeTable: React.FC = () => {
  const M = getMats();
  return (
    <group>
      <mesh position={[-18, 2.9, 0]} material={M.wood} castShadow receiveShadow><boxGeometry args={[15.6, 0.2, 6]} /></mesh>
      <mesh position={[-18, 2.72, 0]} material={M.darkSteel}><boxGeometry args={[15.0, 0.16, 5.4]} /></mesh>
      {[[-25, 2.2], [-11, 2.2], [-25, -2.2], [-11, -2.2]].map(([x, z], i) => (
        <mesh key={i} position={[x + (x < -18 ? 0.6 : -0.6), 1.4, z * 0.85]} rotation={[0, 0, (x < -18 ? 1 : -1) * 0.08]} material={M.darkSteel} castShadow>
          <cylinderGeometry args={[0.1, 0.1, 2.9, 10]} />
        </mesh>
      ))}
    </group>
  );
};
