import React, {useMemo} from 'react';
import * as THREE from 'three';
import {getMats} from '../materials';
import {State} from '../timeline';
import {V3, clamp, lerp} from '../math';
import {Arrow, Gauge, PipeFlow} from './parts';

/** Vertical syringe, nozzle down. `head` = height of oil column = plunger position. */
export const Syringe: React.FC<{r: number; L: number; head: number; rodLen: number; press?: number}> = ({r, L, head, rodLen, press = 0}) => {
  const M = getMats();
  const glow = useMemo(() => new THREE.MeshBasicMaterial({color: '#8fe3ff', transparent: true, opacity: 0, depthWrite: false}), []);
  glow.opacity = 0.35 * press;
  const h = Math.max(head, 0.002);
  return (
    <group>
      {/* oil + barrel */}
      <mesh position={[0, h / 2, 0]} material={M.oil} renderOrder={1}><cylinderGeometry args={[r * 0.95, r * 0.95, h, 40]} /></mesh>
      <mesh position={[0, h / 2, 0]} material={glow} renderOrder={2}><cylinderGeometry args={[r * 0.97, r * 0.97, h, 40]} /></mesh>
      <mesh position={[0, L / 2, 0]} material={M.glass} renderOrder={3}><cylinderGeometry args={[r, r, L, 40, 1, true]} /></mesh>
      {Array.from({length: 8}, (_, k) => (
        <mesh key={k} position={[0, ((k + 1) * L) / 9, 0]} material={M.dark}><cylinderGeometry args={[r * 1.008, r * 1.008, 0.02, 40, 1, true]} /></mesh>
      ))}
      {/* nozzle */}
      <mesh position={[0, -0.175, 0]} material={M.glass} renderOrder={3}><cylinderGeometry args={[r, 0.14, 0.35, 32, 1, true]} /></mesh>
      <mesh position={[0, -0.175, 0]} material={M.oil} renderOrder={1}><cylinderGeometry args={[r * 0.9, 0.12, 0.35, 24]} /></mesh>
      <mesh position={[0, -0.6, 0]} material={M.chrome} castShadow><cylinderGeometry args={[0.1, 0.1, 0.5, 16, 1, true]} /></mesh>
      <mesh position={[0, -0.6, 0]} material={M.oil} renderOrder={1}><cylinderGeometry args={[0.07, 0.07, 0.5, 12]} /></mesh>
      {/* finger flange */}
      <mesh position={[0, L + 0.05, 0]} scale={[1.8, 1, 0.75]} material={M.steel} castShadow><cylinderGeometry args={[r * 1.15, r * 1.15, 0.1, 32]} /></mesh>
      {/* plunger: rubber head, rod, thumb pad */}
      <mesh position={[0, head + 0.17, 0]} material={M.rubber} castShadow><cylinderGeometry args={[r * 0.97, r * 0.97, 0.34, 32]} /></mesh>
      <mesh position={[0, head + 0.34 + rodLen / 2, 0]} material={M.machined} castShadow><cylinderGeometry args={[r * 0.2, r * 0.2, rodLen, 16]} /></mesh>
      <mesh position={[0, head + 0.34 + rodLen + 0.07, 0]} material={M.capBlue} castShadow><cylinderGeometry args={[r * 0.9, r * 0.9, 0.14, 32]} /></mesh>
    </group>
  );
};
export const padTopY = (head: number, rodLen: number) => head + 0.48 + rodLen;

const Glass: React.FC<{x: number; level: number}> = ({x, level}) => {
  const M = getMats();
  return (
    <group position={[x, 0, 0]}>
      <mesh position={[0, 4.2, 0]} material={M.glass} renderOrder={3}><cylinderGeometry args={[1.0, 0.9, 2.4, 40, 1, true]} /></mesh>
      <mesh position={[0, 3.05, 0]} material={M.glass}><cylinderGeometry args={[0.9, 0.9, 0.1, 40]} /></mesh>
      <mesh position={[0, 3.1 + level / 2, 0]} material={M.oil} renderOrder={1}><cylinderGeometry args={[0.96 - 0.03, 0.9 - 0.03, level, 40]} /></mesh>
    </group>
  );
};

/** Scene 1: one syringe draws, pushes, is capped, then cannot compress the oil. */
export const S1Syringe: React.FC<{s: State}> = ({s}) => {
  const M = getMats();
  const X = -23.6, L = 3.2, rodLen = 2.2;
  const yb = 4.45 + s.s1.lift;
  const head = s.s1.fill * L - 0.05 * s.s1.press;
  const tablePos: V3 = [-21.5, 3.25, 0.9];
  const tip: V3 = [X, yb - 0.75, 0];
  const c = s.s1.cap;
  const cp: V3 = [lerp(tablePos[0], tip[0], c), lerp(tablePos[1], tip[1], c) + 1.4 * Math.sin(Math.PI * c), lerp(tablePos[2], tip[2], c)];
  return (
    <group>
      <Glass x={X} level={s.s1.glass} />
      <group position={[X, yb, 0]}><Syringe r={0.42} L={L} head={head} rodLen={rodLen} press={s.s1.press} /></group>
      <mesh position={cp} material={M.capBlue} castShadow><cylinderGeometry args={[0.17, 0.2, 0.5, 24]} /></mesh>
      <Arrow pos={[X, yb + padTopY(head, rodLen) + 1.7 * s.s1.press, 0]} dir={[0, -1, 0]} len={1.7 * s.s1.press} r={0.1} color="#ff9a1f" />
    </group>
  );
};

const RIG = {sx: -19.2, lx: -16.2, yb: 5.3};
const TUBE: V3[] = [[RIG.sx, 4.45, 0], [RIG.sx, 4.0, 0], [RIG.sx + 0.35, 3.75, 0], [RIG.lx - 0.35, 3.75, 0], [RIG.lx, 4.0, 0], [RIG.lx, 4.45, 0]];

/** Scenes 2-3: small syringe drives a 4x larger piston through a oil-filled tube. */
export const SyringeRig: React.FC<{s: State}> = ({s}) => {
  const M = getMats();
  const {sx, lx, yb} = RIG;
  const push = s.rig.push;
  const hs = 4.0 - 3.2 * push; // small oil column (area 1)
  const hl = 0.7 + 0.8 * push; // large oil column (area 4): volume conserved, 4x less travel
  const padS = yb + padTopY(hs, 2.4);
  const padL = yb + padTopY(hl, 3.4);
  const platTop = padL + 0.16;
  const wY = platTop + 0.6 + s.rig.weight.dy;
  const clamp1 = (x: number, r: number, y: number) => {
    const len = 1.59 - (r + 0.05);
    return (
      <group key={`${x}-${y}`}>
        <mesh position={[x, y, 0]} rotation={[Math.PI / 2, 0, 0]} material={M.steel}><torusGeometry args={[r + 0.05, 0.07, 10, 36]} /></mesh>
        <mesh position={[x, y, -(r + 0.05 + len / 2)]} material={M.steel}><boxGeometry args={[0.18, 0.18, len]} /></mesh>
      </group>
    );
  };
  return (
    <group>
      <mesh position={[-17.7, 3.125, 0]} material={M.woodDark} castShadow receiveShadow><boxGeometry args={[7.4, 0.25, 4.4]} /></mesh>
      <mesh position={[-17.7, 6.5, -1.7]} material={M.wood} castShadow receiveShadow><boxGeometry args={[7.4, 6.8, 0.22]} /></mesh>
      {[6.2, 8.4].map((y) => clamp1(sx, 0.5, y))}
      {[6.2, 8.0].map((y) => clamp1(lx, 1.0, y))}
      <group position={[sx, yb, 0]}><Syringe r={0.5} L={4.4} head={hs} rodLen={2.4} /></group>
      <group position={[lx, yb, 0]}><Syringe r={1.0} L={3.6} head={hl} rodLen={3.4} /></group>
      <PipeFlow points={TUBE} radius={0.13} cut={1} shell="glass" flow={s.rig.flow} phase={s.phase.rig} count={22} seed={9} />
      {/* load platform + steel weight on the large piston */}
      <mesh position={[lx, padL + 0.08, 0]} material={M.machined} castShadow><cylinderGeometry args={[1.45, 1.45, 0.16, 40]} /></mesh>
      {s.rig.weight.visible && (
        <group position={[lx, wY, 0]}>
          <mesh material={M.iron} castShadow><boxGeometry args={[2.2, 1.2, 1.6]} /></mesh>
          <mesh position={[0, 0, 0.81]} material={M.yellow}><boxGeometry args={[2.2, 0.3, 0.02]} /></mesh>
          <mesh position={[0, 0.75, 0]} rotation={[0, 0, 0]} material={M.steel}><torusGeometry args={[0.28, 0.07, 10, 24]} /></mesh>
        </group>
      )}
      {/* force arrows: F on the small piston, 4F on the large one */}
      <Arrow pos={[sx, padS + 1.5 * s.rig.arrows + 0.3, 0]} dir={[0, -1, 0]} len={1.0 * s.rig.arrows} r={0.09} color="#ffb020" />
      <Arrow pos={[lx + 1.95, padL - 1.2, 0]} dir={[0, 1, 0]} len={4.0 * s.rig.arrows} r={0.13} color="#ff4a3d" />
    </group>
  );
};

/** Scene 4: sealed vessel — pressure acts equally on every wall (Pascal's law). */
export const PascalVessel: React.FC<{s: State}> = ({s}) => {
  const M = getMats();
  const C: V3 = [-12.2, 5.55, 0], R = 1.7;
  const {P, push} = s.pascal;
  const oilMat = useMemo(() => new THREE.MeshPhysicalMaterial({color: '#1f80ff', transparent: true, opacity: 0.75, roughness: 0.08, emissive: '#0a49cf', emissiveIntensity: 0.3}), []);
  oilMat.emissiveIntensity = 0.3 + 0.9 * P;
  const gdirs = useMemo(() => [new THREE.Vector3(-1, 0.1, 0.55).normalize(), new THREE.Vector3(1, -0.05, 0.55).normalize(), new THREE.Vector3(0, -0.75, 0.66).normalize()], []);
  const arrows = useMemo(() => {
    const out: THREE.Vector3[] = [], n = 30, ga = Math.PI * (3 - Math.sqrt(5));
    for (let i = 0; i < n; i++) {
      const y = 1 - (2 * (i + 0.5)) / n, rr = Math.sqrt(1 - y * y);
      const d = new THREE.Vector3(Math.cos(ga * i) * rr, y, Math.sin(ga * i) * rr);
      if (d.y < 0.88 && d.y > -0.85 && gdirs.every((g) => g.dot(d) < 0.8) && d.z > -0.5) out.push(d);
    }
    return out;
  }, [gdirs]);
  const headY = C[1] + 2.9 - push;
  const quat = (d: THREE.Vector3) => new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 0, 1), d);
  return (
    <group>
      {[0, 1, 2].map((i) => {
        const a = (i / 3) * Math.PI * 2 + 0.5;
        return <mesh key={i} position={[C[0] + Math.cos(a) * 1.05, 3.45, Math.sin(a) * 1.05]} material={M.darkSteel} castShadow><cylinderGeometry args={[0.1, 0.1, 0.9, 10]} /></mesh>;
      })}
      <mesh position={[C[0], 3.9, 0]} rotation={[Math.PI / 2, 0, 0]} material={M.steel}><torusGeometry args={[1.15, 0.1, 10, 36]} /></mesh>
      <mesh position={C} material={oilMat} renderOrder={1}><sphereGeometry args={[R - 0.07, 48, 32]} /></mesh>
      <mesh position={[C[0], C[1] + 2.45 - 0.0, 0]} material={oilMat} renderOrder={1}><cylinderGeometry args={[0.47, 0.47, Math.max(headY - (C[1] + 1.4), 0.01), 24]} /></mesh>
      <mesh position={C} material={M.glass} renderOrder={3}><sphereGeometry args={[R, 48, 32]} /></mesh>
      <mesh position={[C[0], C[1] + 2.5, 0]} material={M.glass} renderOrder={3}><cylinderGeometry args={[0.55, 0.55, 2.2, 28, 1, true]} /></mesh>
      <mesh position={[C[0], headY + 0.17, 0]} material={M.rubber} castShadow><cylinderGeometry args={[0.52, 0.52, 0.34, 24]} /></mesh>
      <mesh position={[C[0], headY + 1.3, 0]} material={M.machined} castShadow><cylinderGeometry args={[0.12, 0.12, 2.0, 12]} /></mesh>
      <mesh position={[C[0], headY + 2.35, 0]} material={M.capBlue} castShadow><cylinderGeometry args={[0.5, 0.5, 0.14, 24]} /></mesh>
      <Arrow pos={[C[0], headY + 2.45 + 1.4 * P, 0]} dir={[0, -1, 0]} len={1.4 * P} r={0.1} color="#ffb020" />
      {arrows.map((d, i) => (
        <Arrow key={i} pos={[C[0] + d.x * (R + 0.08), C[1] + d.y * (R + 0.08), d.z * (R + 0.08)]} dir={[d.x, d.y, d.z]} len={1.0 * P} r={0.07} color="#46d9ff" />
      ))}
      {gdirs.map((d, i) => (
        <group key={i}>
          <mesh position={[C[0] + d.x * (R + 0.15), C[1] + d.y * (R + 0.15), d.z * (R + 0.15)]} quaternion={new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), d)} material={M.steel}><cylinderGeometry args={[0.13, 0.13, 0.4, 12]} /></mesh>
          <Gauge p={P} scale={0.62} position={[C[0] + d.x * (R + 0.62), C[1] + d.y * (R + 0.62), d.z * (R + 0.62)]} quaternion={quat(d)} />
        </group>
      ))}
    </group>
  );
};
