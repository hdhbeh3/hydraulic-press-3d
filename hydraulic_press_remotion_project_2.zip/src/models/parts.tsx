import React, {useLayoutEffect, useMemo, useRef} from 'react';
import * as THREE from 'three';
import {getMats} from '../materials';
import {V3, clamp, mulberry32} from '../math';

/** Force / pressure arrow. Tail at `pos`, pointing along `dir`. */
export const Arrow: React.FC<{pos: V3; dir: V3; len: number; r?: number; color?: string}> = ({pos, dir, len, r = 0.09, color = '#ffb020'}) => {
  const q = useMemo(() => new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3(...dir).normalize()), [dir[0], dir[1], dir[2]]);
  const mat = useMemo(() => new THREE.MeshStandardMaterial({color, emissive: color, emissiveIntensity: 0.8, roughness: 0.4}), [color]);
  if (len < 0.03) return null;
  const head = Math.min(len * 0.5, r * 5.5);
  const shaft = Math.max(len - head, 0.001);
  return (
    <group position={pos} quaternion={q}>
      <mesh position={[0, shaft / 2, 0]} material={mat}><cylinderGeometry args={[r, r, shaft, 12]} /></mesh>
      <mesh position={[0, shaft + head / 2, 0]} material={mat}><coneGeometry args={[r * 2.3, head, 16]} /></mesh>
    </group>
  );
};

/** Bourdon-style pressure gauge, face toward local +z. No text; red zone at the top of the scale. */
export const Gauge: React.FC<{p: number; position: V3; quaternion?: THREE.Quaternion; scale?: number}> = ({p, position, quaternion, scale = 1}) => {
  const M = getMats();
  const ticks = useMemo(() => Array.from({length: 21}, (_, i) => ({a: THREE.MathUtils.degToRad(135 - (270 * i) / 20), major: i % 5 === 0})), []);
  const na = THREE.MathUtils.degToRad(135 - 270 * clamp(p));
  const D = THREE.MathUtils.degToRad;
  return (
    <group position={position} quaternion={quaternion} scale={scale}>
      <mesh rotation={[Math.PI / 2, 0, 0]} material={M.chrome} castShadow><cylinderGeometry args={[0.74, 0.74, 0.3, 40]} /></mesh>
      <mesh position={[0, 0, 0.151]} material={M.gaugeFace}><circleGeometry args={[0.62, 40]} /></mesh>
      <mesh position={[0, 0, 0.155]} material={M.red}><ringGeometry args={[0.4, 0.47, 24, 1, D(-45), D(67.5)]} /></mesh>
      {ticks.map((k, i) => (
        <mesh key={i} position={[-Math.sin(k.a) * 0.53, Math.cos(k.a) * 0.53, 0.165]} rotation={[0, 0, k.a]} material={M.dark}>
          <boxGeometry args={[0.03, k.major ? 0.16 : 0.09, 0.01]} />
        </mesh>
      ))}
      <group position={[0, 0, 0.19]} rotation={[0, 0, na]}>
        <mesh position={[0, 0.2, 0]} material={M.needle}><boxGeometry args={[0.045, 0.46, 0.02]} /></mesh>
        <mesh position={[0, -0.06, 0]} material={M.needle}><boxGeometry args={[0.045, 0.12, 0.02]} /></mesh>
      </group>
      <mesh position={[0, 0, 0.2]} rotation={[Math.PI / 2, 0, 0]} material={M.dark}><cylinderGeometry args={[0.07, 0.07, 0.06, 16]} /></mesh>
      <mesh position={[0, 0, 0.23]} rotation={[Math.PI / 2, 0, 0]} material={M.glass}><cylinderGeometry args={[0.64, 0.64, 0.02, 40]} /></mesh>
    </group>
  );
};

type Shell = 'rubber' | 'steel' | 'glass';
/** Pipe/hose with a see-through shell (cutaway), blue oil core and drifting oil particles. */
export const PipeFlow: React.FC<{
  points: V3[]; radius: number; cut?: number; shell?: Shell; flow?: number; phase?: number; count?: number; seed?: number;
}> = ({points, radius, cut = 0, shell = 'steel', flow = 0, phase = 0, count = 24, seed = 3}) => {
  const M = getMats();
  const segs = Math.max(8, points.length * 12);
  const curve = useMemo(() => new THREE.CatmullRomCurve3(points.map((p) => new THREE.Vector3(...p)), false, 'centripetal'), []);
  const shellGeo = useMemo(() => new THREE.TubeGeometry(curve, segs, radius, 14, false), []);
  const oilGeo = useMemo(() => new THREE.TubeGeometry(curve, segs, radius * 0.78, 12, false), []);
  const shellMat = useMemo(() => new THREE.MeshPhysicalMaterial({
    color: shell === 'rubber' ? '#1b1d20' : '#9aa3ab', metalness: shell === 'steel' ? 0.85 : 0.1,
    roughness: shell === 'rubber' ? 0.7 : 0.35, transparent: true,
  }), []);
  shellMat.opacity = 1 - 0.88 * cut;
  shellMat.depthWrite = shellMat.opacity > 0.9;
  const offs = useMemo(() => { const r = mulberry32(seed); return Array.from({length: count}, (_, i) => (i + (r() - 0.5) * 0.7) / count); }, [count, seed]);
  const ref = useRef<THREE.InstancedMesh>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  const v = useMemo(() => new THREE.Vector3(), []);
  useLayoutEffect(() => {
    const m = ref.current; if (!m) return;
    const vis = cut > 0.15 && Math.abs(flow) > 0.03 ? 0.55 + 0.45 * clamp(flow) : 0;
    offs.forEach((o, i) => {
      const u = (((o + phase) % 1) + 1) % 1;
      curve.getPointAt(u, v);
      dummy.position.copy(v); dummy.scale.setScalar(vis * radius * 0.36);
      dummy.updateMatrix(); m.setMatrixAt(i, dummy.matrix);
    });
    m.instanceMatrix.needsUpdate = true;
  });
  return (
    <group>
      <mesh geometry={oilGeo} material={M.oil} renderOrder={1} />
      <mesh geometry={shellGeo} material={shellMat} castShadow renderOrder={2} />
      <instancedMesh ref={ref} args={[undefined, undefined, count]} frustumCulled={false} renderOrder={3} material={M.flow}>
        <sphereGeometry args={[1, 10, 8]} />
      </instancedMesh>
    </group>
  );
};

/** Deterministic debris/dust burst. */
export const Burst: React.FC<{t: number; t0: number; dur: number; center: V3; count?: number; speed?: number; size?: number; seed?: number}> = ({t, t0, dur, center, count = 40, speed = 3.2, size = 0.1, seed = 5}) => {
  const M = getMats();
  const ref = useRef<THREE.InstancedMesh>(null);
  const dirs = useMemo(() => { const r = mulberry32(seed); return Array.from({length: count}, () => { const a = r() * Math.PI * 2, e = r() * 0.8; return [Math.cos(a) * Math.cos(e), Math.sin(e) + 0.2, Math.sin(a) * Math.cos(e), 0.5 + r()] as [number, number, number, number]; }); }, [count, seed]);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  useLayoutEffect(() => {
    const m = ref.current; if (!m) return;
    const tau = (t - t0) / dur, on = tau >= 0 && tau <= 1;
    dirs.forEach((d, i) => {
      const s = on ? speed * d[3] : 0, tt = tau * dur;
      dummy.position.set(center[0] + d[0] * s * tt, center[1] + d[1] * s * tt - 2.2 * tt * tt, center[2] + d[2] * s * tt);
      dummy.scale.setScalar(on ? size * (1 - tau) * (1.2 + d[3]) : 0);
      dummy.updateMatrix(); m.setMatrixAt(i, dummy.matrix);
    });
    m.instanceMatrix.needsUpdate = true;
  });
  return (
    <instancedMesh ref={ref} args={[undefined, undefined, count]} frustumCulled={false} material={M.dust}>
      <sphereGeometry args={[1, 8, 6]} />
    </instancedMesh>
  );
};
