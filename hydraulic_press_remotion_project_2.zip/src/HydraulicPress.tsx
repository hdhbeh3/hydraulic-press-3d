import React from 'react';
import {AbsoluteFill} from 'remotion';
import {Scene3D} from './Scene3D';
import {AudioTrack} from './audio/AudioTrack';

export const HydraulicPress: React.FC = () => (
  <AbsoluteFill style={{backgroundColor: '#000'}}>
    <Scene3D />
    <AudioTrack />
  </AbsoluteFill>
);

/** Studio-only guide: shows the YouTube Shorts UI zones. Never rendered into the final video. */
export const HydraulicPressSafeZones: React.FC = () => (
  <AbsoluteFill>
    <HydraulicPress />
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      <div style={{position: 'absolute', top: 0, left: 0, right: 0, height: 250, background: 'rgba(255,0,0,0.25)'}} />
      <div style={{position: 'absolute', bottom: 0, left: 0, right: 0, height: 480, background: 'rgba(255,0,0,0.25)'}} />
      <div style={{position: 'absolute', top: 250, bottom: 480, right: 0, width: 120, background: 'rgba(255,160,0,0.25)'}} />
    </AbsoluteFill>
  </AbsoluteFill>
);
