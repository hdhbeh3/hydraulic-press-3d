// Shared machine dimensions (scene units). Press frame is centred on x = 0.
export const BED_Y = 0.9; // top of bed plate
export const H0 = 2.4; // billet height before pressing
export const H1 = 1.0; // billet height fully crushed
export const R0 = 1.0; // billet radius
export const PLATE_UP = 6.0; // plate bottom, fully retracted
export const PLATE_T = 0.5; // plate thickness
export const ROD_LEN = 8.1; // plate top -> piston bottom
export const INNER_BOTTOM = 9.2; // cylinder inner bottom
export const INNER_TOP = 15.2; // cylinder inner top
export const PISTON_T = 0.6;
export const TRAVEL = PLATE_UP - (BED_Y + H1); // 4.1
export const CONTACT = (PLATE_UP - (BED_Y + H0)) / TRAVEL; // ram value at first touch

export const plateBottomFromRam = (ram: number) => PLATE_UP - TRAVEL * ram;
export const pistonBottom = (plateBottom: number) => plateBottom + PLATE_T + ROD_LEN;
export const billetHeight = (c: number) => H0 + (H1 - H0) * c;

// Oil circuit (world coordinates)
export const HOSE_POINTS: [number, number, number][] = [
  [6.0, 7.0, 1.5], [6.1, 8.8, 1.7], [5.4, 11.8, 1.8], [3.7, 14.6, 1.3],
  [2.2, 16.5, 0.6], [0.6, 16.6, 0.15], [0.6, 15.95, 0.0],
];
export const HOSE_LEN = 13.0;
