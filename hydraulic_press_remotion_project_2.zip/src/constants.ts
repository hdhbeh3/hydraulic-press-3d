// Single source of truth for format + narration timing.
export const FPS = 30;
export const WIDTH = 1080;
export const HEIGHT = 1920;

/** Exact duration of the supplied voiceover (press_.m4a), measured with ffprobe. */
export const VO_DURATION_SEC = 70.493;
export const DURATION_FRAMES = Math.ceil(VO_DURATION_SEC * FPS); // 2115
export const DURATION_SEC = DURATION_FRAMES / FPS;

/**
 * Scene boundaries (seconds). Derived from the measured pauses in the voiceover
 * (major breaks at 19.05, 36.38, 54.12 s plus sentence pauses). If you re-time the
 * narration, edit these numbers and the camera keys in camera.ts / events in timeline.ts.
 */
export const SCENES = [
  {id: 'syringe', start: 0.0, end: 7.74},
  {id: 'two_syringes', start: 7.74, end: 15.17},
  {id: 'large_piston', start: 15.17, end: 19.45},
  {id: 'pascal', start: 19.45, end: 27.15},
  {id: 'pump', start: 27.15, end: 36.88},
  {id: 'cylinder', start: 36.88, end: 42.14},
  {id: 'pressing_plate', start: 42.14, end: 45.82},
  {id: 'steel_crushing', start: 45.82, end: 54.6},
  {id: 'release_valve', start: 54.6, end: 63.25},
  {id: 'complete_press', start: 63.25, end: DURATION_SEC},
] as const;

/** YouTube Shorts UI safe-zone: content is shifted up so the subject sits in the clear area. */
export const SAFE_SHIFT_PX = 115;

/** Audio mix (voiceover is always 1.0; everything else sits below it). */
export const MIX = {voiceover: 0.8, music: 0.5, sfx: 0.85, duckAmount: 0.4};
