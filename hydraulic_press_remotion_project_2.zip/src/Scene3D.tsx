import React, {useLayoutEffect, useMemo} from 'react';
import {useCurrentFrame} from 'remotion';
import {ThreeCanvas} from '@remotion/three';
import {useThree} from '@react-three/fiber';
import * as THREE from 'three';
import {FPS, WIDTH, HEIGHT, SAFE_SHIFT_PX} from './constants';
import {cameraAt, shakeAt, FOV} from './camera';
import {getState} from './timeline';
import {Backdrop, CafeTable, EnvMap} from './models/Environment';
import {S1Syringe, SyringeRig, PascalVessel} from './models/Syringes';
import {PressMachine} from './models/PressModel';

/** Drives camera + sun from the timeline, then renders synchronously so every frame is deterministic. */
const Rig: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const {camera, gl, scene} = useThree();
  const cam = cameraAt(t);
  const sh = shakeAt(t);
  const c = camera as THREE.PerspectiveCamera;
  c.fov = FOV;
  c.aspect = WIDTH / HEIGHT;
  c.position.set(cam.pos[0] + sh[0], cam.pos[1] + sh[1], cam.pos[2] + sh[2]);
  c.lookAt(cam.target[0], cam.target[1], cam.target[2]);
  // shift the image up so the subject sits inside the YouTube Shorts safe area
  c.setViewOffset(WIDTH, HEIGHT, 0, SAFE_SHIFT_PX, WIDTH, HEIGHT);
  c.updateProjectionMatrix();

  const sun = useMemo(() => new THREE.DirectionalLight('#ffe7c8', 3.2), []);
  const fill = useMemo(() => new THREE.DirectionalLight('#9fc2ff', 0.7), []);
  const tgt = useMemo(() => new THREE.Object3D(), []);
  const ext = Math.min(22, Math.max(9, cam.height * 0.75));
  tgt.position.set(...cam.target);
  sun.position.set(cam.target[0] + 14, cam.target[1] + 24, cam.target[2] + 18);
  sun.target = tgt;
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  sun.shadow.bias = -0.0004;
  sun.shadow.normalBias = 0.03;
  Object.assign(sun.shadow.camera, {left: -ext, right: ext, top: ext, bottom: -ext, near: 1, far: 90});
  sun.shadow.camera.updateProjectionMatrix();
  fill.position.set(cam.target[0] - 16, cam.target[1] + 10, cam.target[2] + 14);

  useLayoutEffect(() => {
    gl.toneMapping = THREE.ACESFilmicToneMapping;
    gl.toneMappingExposure = 1.05;
    gl.shadowMap.enabled = true;
    gl.shadowMap.type = THREE.PCFSoftShadowMap;
  }, [gl]);
  useLayoutEffect(() => { gl.render(scene, camera); });
  return (
    <>
      <primitive object={tgt} />
      <primitive object={sun} />
      <primitive object={fill} />
    </>
  );
};

const World: React.FC = () => {
  const frame = useCurrentFrame();
  const s = getState(frame / FPS);
  return (
    <>
      <hemisphereLight args={['#d6e6ff', '#4b5a3a', 0.8]} />
      <Backdrop />
      <CafeTable />
      <S1Syringe s={s} />
      <SyringeRig s={s} />
      <PascalVessel s={s} />
      <PressMachine s={s} />
    </>
  );
};

export const Scene3D: React.FC = () => (
  <ThreeCanvas
    width={WIDTH}
    height={HEIGHT}
    shadows
    frameloop="demand"
    camera={{fov: FOV, near: 0.1, far: 400, position: [0, 10, 30]}}
    gl={{antialias: true, preserveDrawingBuffer: true}}
  >
    <EnvMap />
    <World />
    <Rig />
  </ThreeCanvas>
);
