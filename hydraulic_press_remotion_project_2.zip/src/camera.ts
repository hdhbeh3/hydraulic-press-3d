import {V3, clamp} from './math';

export const FOV = 36;
/** [time s, target, visible world height at target, azimuth deg (0 = from +z), elevation deg] */
type Key = [number, V3, number, number, number];

export const CAMERA_KEYS: Key[] = [
  // 1 Syringe
  [0.0, [-20.5, 5.8, 0], 18, -30, 12],
  [2.0, [-23.6, 7.0, 0], 11.5, -12, 8],
  [4.3, [-23.6, 7.2, 0], 11.5, 14, 5],
  [6.4, [-23.6, 6.4, 0], 9, 4, 2],
  // 2 Two connected syringes
  [8.1, [-19.5, 6.6, 0], 12.5, -8, 7],
  [10.8, [-17.9, 4.6, 0], 7.5, 8, 7],
  [13.3, [-17.7, 7.0, 0], 12, -10, 6],
  // 3 Large piston
  [15.6, [-16.2, 7.6, 0], 9.5, -18, 6],
  [17.4, [-16.2, 8.0, 0], 9, 20, 9],
  [19.3, [-15.0, 7.5, 0], 11, 8, 8],
  // 4 Pascal
  [20.4, [-12.2, 5.6, 0], 9.5, -14, 8],
  [23.2, [-12.2, 5.6, 0], 8, 20, 6],
  [25.8, [-11.5, 5.6, 0], 10, 34, 12],
  [27.3, [1.0, 6.0, 1], 28, 52, 15],
  // 5 Pump
  [29.2, [8.0, 4.6, 1], 18, 24, 9],
  [31.4, [6.2, 4.4, 0.5], 6.2, 6, 4],
  [34.0, [6.4, 4.6, 1.0], 6.5, -14, 6],
  [36.0, [6.2, 8.6, 1.5], 11, -12, 10],
  // 6 Cylinder
  [37.6, [2.2, 14.8, 1.0], 8.5, -24, 10],
  [39.8, [0.0, 12.6, 0.0], 9, -4, 3],
  [41.8, [0.0, 12.0, 0.0], 8.5, 16, -3],
  // 7 Pressing plate
  [43.2, [0.0, 5.2, 0.5], 9.5, -12, 2],
  [44.8, [0.0, 3.6, 0.0], 8, 16, -2],
  [45.9, [0.0, 2.9, 0.0], 8, 24, 1],
  // 8 Steel crushing
  [47.0, [0.0, 2.4, 0.0], 8, 32, 5],
  [49.4, [0.0, 2.3, 0.0], 8, 6, 14],
  [51.8, [0.0, 2.1, 0.0], 8, -20, 5],
  [53.8, [0.0, 1.9, 0.0], 8, -12, 3],
  // 9 Release valve
  [55.4, [8.0, 4.4, 1.5], 8, -12, 6],
  [57.0, [8.6, 4.6, 1.5], 7.5, 22, 6],
  [59.0, [6.6, 5.4, 1.8], 8, 6, 8],
  [60.8, [3.5, 10.0, 0.6], 18, -8, 7],
  [62.4, [0.6, 6.0, 0.0], 11, 10, 3],
  // 10 Complete press
  [63.6, [1.5, 6.0, 0.5], 15, 20, 6],
  [66.0, [4.0, 7.5, 0.5], 24, -22, 10],
  [68.6, [5.0, 7.8, 0.5], 29, -6, 9],
  [70.6, [5.2, 7.8, 0.5], 31, 0, 8],
];

const chan = (k: Key): number[] => [k[1][0], k[1][1], k[1][2], Math.log(k[2]), k[3], k[4]];
const VALS = CAMERA_KEYS.map(chan);

/** Cubic Hermite with Catmull-Rom tangents over non-uniform key times -> continuous velocity. */
function evalChannels(t: number): number[] {
  const n = CAMERA_KEYS.length;
  const T = CAMERA_KEYS.map((k) => k[0]);
  if (t <= T[0]) return VALS[0];
  if (t >= T[n - 1]) return VALS[n - 1];
  let i = 0;
  while (i < n - 2 && t > T[i + 1]) i++;
  const dt = T[i + 1] - T[i];
  const u = (t - T[i]) / dt;
  const tan = (j: number, c: number) => {
    if (j <= 0 || j >= n - 1) return 0;
    return (0.9 * (VALS[j + 1][c] - VALS[j - 1][c])) / (T[j + 1] - T[j - 1]);
  };
  const u2 = u * u, u3 = u2 * u;
  const h00 = 2 * u3 - 3 * u2 + 1, h10 = u3 - 2 * u2 + u, h01 = -2 * u3 + 3 * u2, h11 = u3 - u2;
  return VALS[i].map(
    (_, c) => h00 * VALS[i][c] + h10 * dt * tan(i, c) + h01 * VALS[i + 1][c] + h11 * dt * tan(i + 1, c),
  );
}

export function cameraAt(t: number) {
  const [tx, ty, tz, lnH, az, el] = evalChannels(t);
  const H = Math.exp(lnH);
  const dist = H / 2 / Math.tan((FOV * Math.PI) / 360);
  const a = (az * Math.PI) / 180, e = (el * Math.PI) / 180;
  const target: V3 = [tx, ty, tz];
  const pos: V3 = [
    tx + dist * Math.sin(a) * Math.cos(e),
    ty + dist * Math.sin(e),
    tz + dist * Math.cos(a) * Math.cos(e),
  ];
  return {pos, target, height: H};
}

/** Tiny physical camera shake while the press loads the steel (impacts line up with SFX). */
export const BANG_TIMES = [46.6, 47.6, 49.5, 51.3, 52.3];
export function shakeAt(t: number): V3 {
  const load = clamp((t - 46.6) / 0.4) * (1 - clamp((t - 52.4) / 0.6));
  let amp = 0.012 * load;
  for (const b of BANG_TIMES) if (t >= b) amp += 0.05 * Math.exp(-(t - b) * 9);
  return [amp * Math.sin(t * 61), amp * Math.sin(t * 53 + 1.3), amp * Math.sin(t * 47 + 2.1)];
}
