import React, {useRef} from 'react';
import {useFrame, useThree} from '@react-three/fiber';
import * as THREE from 'three';

type Props = {scene: number; progress: number; frame: number};
const steel = new THREE.MeshStandardMaterial({color: '#8795a2', metalness: 0.88, roughness: 0.24});
const darkSteel = new THREE.MeshStandardMaterial({color: '#303c48', metalness: 0.82, roughness: 0.32});
const blueOil = new THREE.MeshPhysicalMaterial({color: '#087cff', emissive: '#003b8e', emissiveIntensity: 0.35, metalness: 0.05, roughness: 0.18, transparent: true, opacity: 0.72});
const glass = new THREE.MeshPhysicalMaterial({color: '#9bdcff', roughness: 0.08, metalness: 0, transmission: 0.72, transparent: true, opacity: 0.28});
const groundMat = new THREE.MeshStandardMaterial({color: '#26333b', roughness: 0.88});
const gold = new THREE.MeshStandardMaterial({color: '#d6a84e', metalness: 0.72, roughness: 0.25});

const Box: React.FC<{p:[number,number,number]; s:[number,number,number]; m?:THREE.Material; r?:[number,number,number]}> = ({p,s,m=steel,r=[0,0,0]}) => <mesh position={p} rotation={r} material={m} castShadow receiveShadow><boxGeometry args={s}/></mesh>;
const Cylinder: React.FC<{p:[number,number,number]; r:number; h:number; m?:THREE.Material; rot?:[number,number,number]; r2?:number}> = ({p,r,h,m=steel,rot=[0,0,0],r2=r}) => <mesh position={p} rotation={rot} material={m} castShadow receiveShadow><cylinderGeometry args={[r2,r,h,48]}/></mesh>;

function Syringe({large=false, x=0, y=0, z=0, progress=0}: {large?:boolean;x?:number;y?:number;z?:number;progress:number}) {
  const scale = large ? 1.55 : 0.9;
  const plunger = interpolateSafe(progress, [0,1], [0.25,-0.28]);
  return <group position={[x,y,z]} scale={scale} rotation={[0,0,-Math.PI/2]}>
    <mesh position={[0,0,0]} material={glass}><cylinderGeometry args={[0.34,0.34,2.0,48,1,true]}/></mesh>
    <Cylinder p={[0,-0.86,0]} r={0.35} h={0.12} m={darkSteel}/>
    <Cylinder p={[0,0.65,0]} r={0.34} h={0.09} m={steel}/>
    <Cylinder p={[0,plunger,0]} r={0.29} h={0.1} m={blueOil}/>
    <Cylinder p={[0,plunger+0.65,0]} r={0.065} h={1.25} m={steel}/>
    <Cylinder p={[0,plunger+1.34,0]} r={0.25} h={0.12} m={darkSteel}/>
    <Cylinder p={[0,-1.15,0]} r={0.09} h={0.55} m={blueOil}/>
    <mesh position={[0,-0.35,0]} material={blueOil}><cylinderGeometry args={[0.31,0.31,0.85,48]}/></mesh>
  </group>;
}
function interpolateSafe(v:number, range:[number,number], out:[number,number]) {return THREE.MathUtils.mapLinear(THREE.MathUtils.clamp(v,0,1),range[0],range[1],out[0],out[1]);}

function Press({progress, crush=false, cutaway=false}:{progress:number;crush?:boolean;cutaway?:boolean}) {
  const ramY = 3.0 - progress*1.2;
  const blockY = crush ? 0.42 - progress*0.18 : 0.45;
  return <group>
    {/* H-frame press */}
    <Box p={[-2.15,1.8,0]} s={[0.42,4.5,0.65]} m={darkSteel}/><Box p={[2.15,1.8,0]} s={[0.42,4.5,0.65]} m={darkSteel}/>
    <Box p={[0,4.0,0]} s={[4.65,0.48,0.85]} m={steel}/><Box p={[0,-0.42,0]} s={[4.65,0.55,1.05]} m={steel}/>
    <Box p={[-2.15,1.8,0.36]} s={[0.12,3.6,0.08]} m={gold}/><Box p={[2.15,1.8,0.36]} s={[0.12,3.6,0.08]} m={gold}/>
    {/* hydraulic cylinder and ram */}
    <Cylinder p={[0,4.72,0]} r={0.78} h={1.0} m={darkSteel}/><Cylinder p={[0,4.15,0]} r={0.63} h={0.22} m={steel}/>
    <Cylinder p={[0,ramY+0.3,0]} r={0.34} h={2.1} m={steel}/>
    <Box p={[0,ramY-0.8,0]} s={[2.35,0.28,0.8]} m={steel}/>
    <Box p={[0,blockY,0]} s={[1.1,0.8,0.72]} m={crush ? gold : darkSteel}/>
    {crush && <Box p={[0,blockY+0.48,0]} s={[1.18,0.1,0.78]} m={gold}/>}
    {cutaway && <mesh position={[0,4.72,0.42]} material={glass}><cylinderGeometry args={[0.79,0.79,1.0,48,1,true]}/></mesh>}
    {/* reservoir and pump */}
    <Box p={[-3.1,0.0,0]} s={[1.15,0.8,0.85]} m={darkSteel}/><Box p={[-3.1,0.43,0]} s={[1.08,0.06,0.78]} m={blueOil}/>
    <Cylinder p={[-3.0,0.75,0]} r={0.35} h={0.45} m={steel}/><Cylinder p={[-2.55,1.05,0]} r={0.2} h={0.7} m={gold} rot={[0,0,Math.PI/2]}/>
    <mesh position={[-2.1,1.05,0]} rotation={[0,0,Math.PI/2]} material={blueOil}><cylinderGeometry args={[0.09,0.09,1.2,24]}/></mesh>
    <mesh position={[-0.95,2.3,0]} rotation={[0,0,Math.PI/2]} material={blueOil}><cylinderGeometry args={[0.08,0.08,2.2,24]}/></mesh>
  </group>;
}

export const Scene3D: React.FC<Props> = ({scene, progress, frame}) => {
  const group = useRef<THREE.Group>(null);
  const {camera} = useThree();
  useFrame(() => {
    const target = scene === 0 ? new THREE.Vector3(0,0,0) : new THREE.Vector3(0,1.8,0);
    const close = scene >= 6 ? 7.5 : scene <= 2 ? 8.5 : 10;
    const camX = Math.sin(progress*Math.PI*2)*0.55 + (scene===0?-0.2:0.25);
    camera.position.lerp(new THREE.Vector3(camX, scene<=1?3.1:4.0, close), 0.035);
    camera.lookAt(target);
    if(group.current) group.current.rotation.y = scene>=9 ? progress*0.6 : 0;
  });
  return <group ref={group}>
    <mesh position={[0,-0.9,0]} rotation={[-Math.PI/2,0,0]} receiveShadow material={groundMat}><planeGeometry args={[30,30]}/></mesh>
    <gridHelper args={[24,24,'#344552','#25333e']} position={[0,-0.88,0]}/>
    {scene===0 && <><Box p={[0,-0.15,0]} s={[5,0.22,2.5]} m={new THREE.MeshStandardMaterial({color:'#76553b',roughness:0.75})}/><Syringe progress={progress} x={0} y={1.0} z={0}/><mesh position={[0,0.4,0.45]} material={blueOil}><sphereGeometry args={[0.15,24,24]}/></mesh></>}
    {scene===1 && <><Syringe progress={progress} x={-1.55} y={1.25} z={0}/><Syringe progress={1-progress} x={1.55} y={1.25} z={0}/><mesh position={[0,1.25,0]} material={blueOil}><cylinderGeometry args={[0.09,0.09,2.0,24]}/></mesh><Box p={[0,-0.3,0]} s={[5,0.18,1.6]} m={darkSteel}/></>}
    {scene===2 && <><Syringe progress={progress} x={-1.5} y={1.2} z={0}/><Syringe large={true} progress={1-progress} x={1.6} y={1.2} z={0}/><Box p={[0,-0.35,0]} s={[5,0.2,1.6]} m={darkSteel}/></>}
    {scene===3 && <><Cylinder p={[0,1.2,0]} r={1.35} h={2.4} m={glass}/><Cylinder p={[0,1.2,0]} r={1.18} h={2.15} m={blueOil}/><Cylinder p={[0,2.35,0]} r={1.15} h={0.15} m={steel}/><Cylinder p={[0,2.8,0]} r={0.22} h={1.0} m={steel}/>{Array.from({length:8},(_,i)=><mesh key={i} position={[Math.cos(i*Math.PI/4)*0.9,1.2,Math.sin(i*Math.PI/4)*0.9]} material={new THREE.MeshBasicMaterial({color:'#48baff'})}><sphereGeometry args={[0.07,12,12]}/></mesh>)}</>}
    {scene===4 && <><Syringe progress={progress} x={0} y={1.2} z={0}/><Cylinder p={[0,-0.1,0]} r={0.22} h={0.55} m={blueOil}/><Box p={[0,-0.5,0]} s={[4,0.15,1.2]} m={darkSteel}/></>}
    {scene===5 && <><Press progress={progress*0.2} cutaway/></>}
    {scene===6 && <><Press progress={progress*0.45} cutaway/><Cylinder p={[-3.1,0.9,0]} r={0.27} h={0.5} m={gold}/></>}
    {scene===7 && <><Press progress={progress} crush/><Box p={[0,0.1,0]} s={[1.0,0.25,0.8]} m={gold}/></>}
    {scene===8 && <><Press progress={1-progress} crush cutaway/><mesh position={[-1.0,2.0,0.48]} material={blueOil}><sphereGeometry args={[0.12,16,16]}/></mesh></>}
    {scene===9 && <><Press progress={0.2+progress*0.8} crush/><mesh position={[0,2.0,-0.8]} material={new THREE.MeshBasicMaterial({color:'#4ca9ff',transparent:true,opacity:0.15})}><sphereGeometry args={[2.5,24,24]}/></mesh></>}
  </group>;
};
