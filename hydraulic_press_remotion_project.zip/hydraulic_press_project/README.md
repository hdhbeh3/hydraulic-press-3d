# Hydraulic Press — Remotion + Three.js

A vertical 3D machine explainer built for GitHub Actions rendering. The supplied original narration is included at `public/voiceover.m4a` and is played unchanged.

## Project specs

- Composition: `HydraulicPress`
- Resolution: 1080 × 1920 (9:16)
- Frame rate: 30 FPS
- Duration: 2,115 frames = 70.5 seconds (the source audio is approximately 70.493 seconds)
- Output: H.264 MP4 at `out/hydraulic_press_final.mp4`
- Renderer: Remotion 4.0.250 + React Three Fiber / Three.js

## Render on GitHub Actions

1. Create a GitHub repository and upload the contents of this folder to its root (do not upload the enclosing folder as an extra nested directory).
2. Open **Actions** and enable workflows if GitHub asks.
3. Select **Render Hydraulic Press Short** and press **Run workflow**. It also runs on pushes to `main`.
4. Wait for the workflow to finish successfully.
5. Open the successful workflow run, scroll to **Artifacts**, and download `hydraulic-press-final-video`.

The workflow installs Node dependencies, installs Chromium system libraries, ensures the Remotion browser, renders the MP4, and uploads it as a downloadable artifact.

## Local render (optional)

Requires Node.js 20 and FFmpeg/system Chromium libraries compatible with Remotion.

```bash
npm install
npx remotion browser ensure
npm run render
```

## Audio and timing

The voiceover file is the original user-supplied `press .m4a` audio, copied byte-for-byte to `public/voiceover.m4a`. The composition is 2,115 frames at 30 FPS (70.5 seconds), so the audio is not regenerated or replaced. Scene boundaries are currently staged against the supplied pause-detection intervals; fine-grained word-level timing should be reviewed against the rendered result.

Initial scene blocks:

| Scene | Approx. time | Visual |
|---|---:|---|
| 1 | 0–8 s | Syringe demonstration on a tabletop |
| 2 | 8–12 s | Two connected syringes and fluid transfer |
| 3 | 12–15.5 s | Small piston / larger piston force comparison |
| 4 | 15.5–19.5 s | Pascal's-law pressure visualization |
| 5 | 19.5–23.5 s | Piston travel and force trade-off demonstration |
| 6 | 23.5–30 s | Hydraulic pump, reservoir and oil line reveal |
| 7 | 30–37 s | Industrial press frame and cylinder cutaway |
| 8 | 37–46.5 s | Ram descends and presses the steel workpiece |
| 9 | 46.5–55.5 s | Steel block deformation / crushing |
| 10 | 55.5–70.5 s | Release/return flow and complete press reveal |

## Visual reference

Selected still frames from the supplied pumpjack reference are in `reference_frames/`. They are included as visual guidance only; the reference video itself is not redistributed in this project.

## Mechanical note

The 3D scene is an explanatory stylized model, not a manufacturing CAD model. Hydraulic press motion is represented as a ram extending downward from the cylinder. A real press circuit may use a motor-driven pump, directional control valve, pressure-relief valve, reservoir, return line, seals and gravity/spring-assisted return depending on its design.

## Verification status

**Not rendered or runtime-tested in this workspace.** Package installation and Remotion browser downloads were unavailable here. The GitHub Actions workflow is included for cloud rendering, but the first GitHub run must be treated as the integration test. Review the resulting MP4 for scene timing, visual quality and audio sync before publishing.
