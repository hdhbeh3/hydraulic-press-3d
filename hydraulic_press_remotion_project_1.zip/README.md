# Hydraulic Press — 3D explainer Short (Remotion)

1080 × 1920 · 30 fps · H.264 MP4 · **2115 frames = 70.5 s** (your voiceover, 70.493 s, unchanged).

> ## Status: RENDER UNTESTED
> This project was built in an environment with **no network access**, so Remotion / Chromium could not be
> installed and **the video has not been rendered or visually inspected**. What *was* verified offline:
> timeline + camera logic (`npm test`), TypeScript/TSX syntax and import resolution, every referenced asset
> exists, the synthesized audio and the final mix levels. Expect to review the first render and tweak camera
> keys if any framing needs adjusting (see "Tuning").

## Render on GitHub Actions
1. Upload the *contents* of this folder to the root of your repo (so `package.json` is at the top level).
2. Repo → **Actions → "Render Hydraulic Press" → Run workflow** (also runs on push to `main`).
3. When done, download the artifact **hydraulic_press_final** → `hydraulic_press_final.mp4`.

## Render locally / Kaggle
```bash
npm install
npm test                 # timeline, camera, SFX schedule checks
npm run check            # syntax + asset checks
npm run start            # Remotion Studio (open composition "HydraulicPressSafeZones" to see Shorts UI zones)
npm run render           # -> out/hydraulic_press_final.mp4
npm run render:preview   # half-resolution quick look
npm run still            # single frame -> out/frame.png
```
Kaggle (Internet ON): `!bash scripts/setup_kaggle.sh` then `!npm run render`.
Linux needs Chrome libraries (installed by the workflow / `setup_kaggle.sh`). Rendering uses software WebGL
(`--gl=swangle`), so expect a long render (roughly 1–3 h on a 4-core runner; estimate, not measured).
Lower `--concurrency` if the runner runs out of memory.

## What's in the video (scene order, matched to pauses measured in your voiceover)
| s | Scene | Key action |
|---|---|---|
| 0–7.7 | Syringe | draws & pushes blue oil, is capped, oil can't be compressed |
| 7.7–15.2 | Two connected syringes | small piston → oil in tube → 4× larger piston; force arrows |
| 15.2–19.5 | Large piston | steel weight lifted (force × 4, distance ÷ 4) |
| 19.5–27.2 | Pascal's law | sealed vessel, equal pressure arrows + 3 identical gauges |
| 27.2–36.9 | Hydraulic pump | hand-lever pump cutaway, inlet/outlet check valves, reservoir |
| 36.9–42.1 | Hydraulic cylinder | cutaway: piston, seals, rod, return spring, oil above piston |
| 42.1–45.8 | Pressing plate | platen descends on guide columns |
| 45.8–54.6 | Steel crushing | billet squashes & barrels, pressure gauge climbs, dust, camera shake |
| 54.6–63.3 | Release valve | needle valve opens, oil returns to tank, spring lifts the ram |
| 63.3–70.5 | Complete press | second pressing cycle, translucent oil circuit, pull-back to hero shot |

No captions, no on-screen text. All 3D models, textures, sounds and music are generated locally.

## Audio
* `public/audio/voiceover.m4a` — your original file, byte-identical, played at 0.8 gain (headroom; the file is very hot).
* `music.wav` — subtle synthesized pad + soft bells. `sfx_bed.wav` — 69 timed SFX (plunger, clicks, check valves,
  lever strokes, thuds, metal crush/bangs, valve turn, hiss, spring) + motion-driven hydraulic hum/flow/splash loops,
  generated from the same timeline that drives the animation.
* Music and SFX duck automatically while you speak (`src/data/voiceover_envelope.json`).
  Measured: music ≈ 15 dB and SFX ≈ 15 dB below the voice; mix peak 0.97 (no clipping).
* Regenerate audio after changing timing: `npm run audio` (needs Python 3 with numpy + scipy, and ffmpeg).

## Tuning
* **Narration timing:** the script text was not available, so scene boundaries come from measured pauses.
  Edit `SCENES` in `src/constants.ts`; camera keys in `src/camera.ts`; animation windows and SFX in `src/timeline.ts`
  (all times in seconds). Run `npm test` and `npm run audio` after edits.
* **Levels:** `MIX` in `src/constants.ts`.
* **Quality vs speed:** `package.json` → `render` (crf, concurrency); shadow map size in `src/Scene3D.tsx`.
* **Safe zones:** the image is shifted up by `SAFE_SHIFT_PX`; the main subject is framed in the central ~60%.

## Layout
```
src/camera.ts      cinematic camera path (Hermite spline keys, shake)
src/timeline.ts    every animation channel + SFX schedule (pure functions of time)
src/models/        syringes, Pascal vessel, press frame/cylinder/pump/valve, environment
src/audio/         voiceover + music + SFX bed with ducking
scripts/           tests, audio synthesis/mix/verify, static checks
.github/workflows/render.yml
```
