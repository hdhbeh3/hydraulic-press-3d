import React, {useLayoutEffect, useMemo} from 'react';
import * as THREE from 'three';
import {getMats} from '../materials';
import {State} from '../timeline';
import {V3, clamp} from '../math';
import {Arrow, Gauge, PipeFlow, Burst} from './parts';
import {BED_Y, H0, R0, INNER_BOTTOM, INNER_TOP, PISTON_T, PLATE_T, ROD_LEN, HOSE_POINTS, pistonBottom, billetHeight} from '../geometry';

const useFadeMat = (color: string, metal: number, rough: number, cut: number) => {
  const m = useMemo(() => new THREE.MeshPhysicalMaterial({color, metalness: metal, roughness: rough, transparent: true}), []);
  m.opacity = 1 - 0.9 * cut;
  m.depthWrite = m.opacity > 0.9;
  return m;
};

const Frame: React.FC = () => {
  const M = getMats();
  return (
    <group>
      <mesh position={[0, 0.43, 0]} material={M.paintDark} castShadow receiveShadow><boxGeometry args={[8, 0.66, 3.2]} /></mesh>
      <mesh position={[0, 0.83, 0]} material={M.machined} castShadow receiveShadow><boxGeometry args={[5.4, 0.14, 2.6]} /></mesh>
      {[-1.6, -0.5, 0.5, 1.6].map((x) => <mesh key={x} position={[x * 0.9, 0.905, 0]} material={M.dark}><boxGeometry args={[0.07, 0.01, 2.6]} /></mesh>)}
      {[-2.6, 2.6].map((x) => (
        <group key={x}>
          <mesh position={[x, 0.9, 0]} material={M.darkSteel} castShadow><cylinderGeometry args={[0.55, 0.6, 0.3, 24]} /></mesh>
          <mesh position={[x, 4.4, 0]} material={M.chrome} castShadow><cylinderGeometry args={[0.32, 0.32, 7.0, 28]} /></mesh>
          <mesh position={[x, 9.15, 0]} material={M.darkSteel} castShadow><cylinderGeometry args={[0.5, 0.5, 0.3, 6]} /></mesh>
        </group>
      ))}
      <mesh position={[0, 8.4, 0]} material={M.paint} castShadow receiveShadow><boxGeometry args={[7.6, 1.2, 2.2]} /></mesh>
      <mesh position={[0, 7.78, 0]} material={M.darkSteel}><cylinderGeometry args={[0.62, 0.62, 0.06, 32]} /></mesh>
      <mesh position={[3.9, 4.9, 0]} rotation={[0, 0, 0]} material={M.yellow}><boxGeometry args={[0.04, 9.5, 1.0]} /></mesh>
    </group>
  );
};

const Plate: React.FC<{y: number}> = ({y}) => {
  const M = getMats();
  return (
    <group position={[0, y, 0]}>
      <mesh position={[0, PLATE_T / 2, 0]} material={M.machined} castShadow receiveShadow><boxGeometry args={[3.4, PLATE_T, 2.2]} /></mesh>
      <mesh position={[0, PLATE_T + 0.17, 0]} material={M.darkSteel} castShadow><cylinderGeometry args={[0.72, 0.72, 0.34, 32]} /></mesh>
      {[-1, 1].map((s) => (
        <group key={s}>
          <mesh position={[s * 2.1, 0.45, 0]} material={M.darkSteel} castShadow><boxGeometry args={[1.0, 0.4, 0.9]} /></mesh>
          <mesh position={[s * 2.6, 0.4, 0]} material={M.darkSteel} castShadow><cylinderGeometry args={[0.5, 0.5, 0.8, 24]} /></mesh>
        </group>
      ))}
    </group>
  );
};

/** Steel billet: volume-conserving squash with barrelling + rim ripples. */
const Workpiece: React.FC<{c: number}> = ({c}) => {
  const M = getMats();
  const geo = useMemo(() => {
    const g = new THREE.CylinderGeometry(1, 1, 1, 56, 30);
    g.userData.orig = (g.attributes.position.array as Float32Array).slice();
    return g;
  }, []);
  const h = billetHeight(c);
  useLayoutEffect(() => {
    const pos = geo.attributes.position as THREE.BufferAttribute;
    const o = geo.userData.orig as Float32Array;
    const k = Math.sqrt(H0 / h) * R0;
    for (let i = 0; i < pos.count; i++) {
      const x0 = o[i * 3], y0 = o[i * 3 + 1], z0 = o[i * 3 + 2];
      let s = k * (1 + 0.1 * c * (1 - 4 * y0 * y0));
      const rim = Math.hypot(x0, z0) > 0.99 ? 1 + 0.025 * c * Math.sin(7 * Math.atan2(z0, x0) + y0 * 5) : 1;
      s *= rim;
      pos.setXYZ(i, x0 * s, y0 * h, z0 * s);
    }
    pos.needsUpdate = true;
    geo.computeVertexNormals();
    geo.computeBoundingSphere();
  });
  return <mesh geometry={geo} material={M.billet} position={[0, BED_Y + h / 2, 0]} castShadow receiveShadow frustumCulled={false} />;
};

const Spring: React.FC<{h: number}> = ({h}) => {
  const M = getMats();
  const hq = Math.round(h / 0.04) * 0.04;
  const geo = useMemo(() => {
    const pts: THREE.Vector3[] = [], turns = 9, n = turns * 14;
    for (let i = 0; i <= n; i++) { const a = (i / n) * turns * Math.PI * 2; pts.push(new THREE.Vector3(Math.cos(a) * 0.62, (i / n) * hq, Math.sin(a) * 0.62)); }
    return new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), n * 2, 0.055, 8, false);
  }, [hq]);
  useLayoutEffect(() => () => geo.dispose(), [geo]);
  return <mesh geometry={geo} material={M.steel} position={[0, INNER_BOTTOM, 0]} castShadow />;
};

const HydraulicCylinder: React.FC<{s: State; plateBottom: number}> = ({s, plateBottom}) => {
  const M = getMats();
  const cut = s.cut.cyl;
  const barrel = useFadeMat('#1f7e88', 0.5, 0.35, cut);
  const oilMat = useMemo(() => new THREE.MeshPhysicalMaterial({color: '#1f80ff', transparent: true, opacity: 0.78, roughness: 0.08, emissive: '#0a49cf'}), []);
  oilMat.emissiveIntensity = 0.3 + 0.9 * s.P;
  const pb = pistonBottom(plateBottom), pt = pb + PISTON_T;
  const oilH = Math.max(INNER_TOP - pt, 0.001);
  const midY = (INNER_BOTTOM + INNER_TOP) / 2, len = INNER_TOP - INNER_BOTTOM;
  const parr: V3[] = [[-0.5, 0, 0], [0.5, 0, 0], [0, 0, -0.5], [0, 0, 0.5], [0, 0, 0]];
  return (
    <group>
      <mesh position={[0, midY, 0]} material={barrel} castShadow renderOrder={3}><cylinderGeometry args={[1.05, 1.05, len, 48, 1, true]} /></mesh>
      <mesh position={[0, INNER_BOTTOM + 0.0 + 0.0 - 0.1, 0]} material={M.darkSteel} castShadow><cylinderGeometry args={[1.4, 1.4, 0.4, 40]} /></mesh>
      <mesh position={[0, INNER_TOP + 0.125, 0]} material={M.darkSteel} castShadow><cylinderGeometry args={[1.4, 1.4, 0.45, 40]} /></mesh>
      {[45, 135, 225, 315].map((a) => <mesh key={a} position={[Math.cos((a * Math.PI) / 180) * 1.27, 12.2, Math.sin((a * Math.PI) / 180) * 1.27]} material={M.chrome} castShadow><cylinderGeometry args={[0.07, 0.07, 6.6, 10]} /></mesh>)}
      <mesh position={[0.6, INNER_TOP + 0.65, 0]} material={M.brass} castShadow><cylinderGeometry args={[0.3, 0.3, 0.7, 20]} /></mesh>
      {/* oil above the piston (pressure side) */}
      <mesh position={[0, pt + oilH / 2, 0]} material={oilMat} renderOrder={1}><cylinderGeometry args={[0.86, 0.86, oilH, 40]} /></mesh>
      {/* piston, seals, rod */}
      <mesh position={[0, pb + PISTON_T / 2, 0]} material={M.machined} castShadow><cylinderGeometry args={[0.86, 0.86, PISTON_T, 40]} /></mesh>
      {[0.14, 0.46].map((d) => <mesh key={d} position={[0, pb + d, 0]} rotation={[Math.PI / 2, 0, 0]} material={M.rubber}><torusGeometry args={[0.86, 0.06, 10, 40]} /></mesh>)}
      <mesh position={[0, plateBottom + PLATE_T + ROD_LEN / 2, 0]} material={M.chrome} castShadow><cylinderGeometry args={[0.38, 0.38, ROD_LEN, 28]} /></mesh>
      <mesh position={[0, INNER_BOTTOM + 0.02, 0]} rotation={[Math.PI / 2, 0, 0]} material={M.rubber}><torusGeometry args={[0.4, 0.06, 10, 28]} /></mesh>
      <Spring h={Math.max(pb - INNER_BOTTOM, 0.3)} />
      {cut > 0.3 && oilH > 0.9 && parr.map((p, i) => <Arrow key={i} pos={[p[0], pt + 0.2 + 0.3 + 0.9 * s.P, p[2]]} dir={[0, -1, 0]} len={0.2 + 0.9 * s.P} r={0.06} color="#7fe6ff" />)}
    </group>
  );
};

const LEVER = {px: 8.4, py: 6.2};

const PumpUnit: React.FC<{s: State}> = ({s}) => {
  const M = getMats();
  const {pump, cut, valve} = s;
  const tankMat = useFadeMat('#1b7a84', 0.35, 0.5, cut.tank);
  const barrelMat = useFadeMat('#6f7a82', 0.8, 0.35, cut.pump);
  const valveMat = useFadeMat('#8a949b', 0.85, 0.35, cut.valve);
  const yf = 4.85 + 0.6 * pump.p; // plunger face
  const leftY = LEVER.py + 2.4 * Math.sin(pump.theta);
  const lvl = s.tankLevel;
  const hosePh = s.phase.hose;
  const flowOut = clamp(Math.max(pump.outlet, valve) + s.hoseFlow);
  const vOpen = valve * 0.55;
  const xN = 7.75 + vOpen, xW = 9.0 + vOpen;
  const SUC: V3[] = [[6, 0.8, 0], [6, 3.5, 0]];
  const OUTC: V3[] = [[6, 3.9, 0.45], [6, 3.9, 1.5]];
  const RISER: V3[] = [[6, 3.9, 1.5], [6, 7.0, 1.5]];
  const TEE: V3[] = [[6, 4.6, 1.5], [7.2, 4.6, 1.5]];
  const RET: V3[] = [[7.8, 4.6, 1.5], [7.8, 2.6, 1.5]];
  return (
    <group>
      {/* reservoir with oil level */}
      {[[3.9, -1.4], [9.1, -1.4], [3.9, 1.4], [9.1, 1.4]].map(([x, z], i) => <mesh key={i} position={[x, 0.2, z]} material={M.darkSteel} castShadow><boxGeometry args={[0.5, 0.2, 0.5]} /></mesh>)}
      <mesh position={[6.5, 0.45 + lvl / 2, 0]} material={M.oil} renderOrder={1}><boxGeometry args={[5.8, lvl, 3.4]} /></mesh>
      <mesh position={[6.5, 1.55, 0]} material={tankMat} castShadow receiveShadow renderOrder={2}><boxGeometry args={[6.0, 2.5, 3.6]} /></mesh>
      <mesh position={[4.6, 3.0, -1.0]} material={M.darkSteel} castShadow><cylinderGeometry args={[0.35, 0.35, 0.4, 20]} /></mesh>
      {/* pump block + barrel */}
      <mesh position={[6, 3.15, 0]} material={M.paintDark} castShadow><boxGeometry args={[1.8, 0.7, 1.6]} /></mesh>
      <mesh position={[6, 4.55, 0]} material={barrelMat} castShadow renderOrder={3}><cylinderGeometry args={[0.62, 0.62, 2.1, 36, 1, true]} /></mesh>
      <mesh position={[6, 5.8, 0]} material={M.darkSteel} castShadow><cylinderGeometry args={[0.75, 0.75, 0.35, 30]} /></mesh>
      <mesh position={[6, (3.5 + yf - 0.35) / 2, 0]} material={M.oil} renderOrder={1}><cylinderGeometry args={[0.55, 0.55, Math.max(yf - 0.35 - 3.5, 0.01), 28]} /></mesh>
      <mesh position={[6, yf - 0.17, 0]} material={M.machined} castShadow><cylinderGeometry args={[0.55, 0.55, 0.35, 28]} /></mesh>
      <mesh position={[6, yf - 0.1, 0]} rotation={[Math.PI / 2, 0, 0]} material={M.rubber}><torusGeometry args={[0.55, 0.05, 8, 28]} /></mesh>
      <mesh position={[6, (yf + leftY) / 2, 0]} material={M.chrome} castShadow><cylinderGeometry args={[0.14, 0.14, leftY - yf, 14]} /></mesh>
      {/* check valve balls */}
      <mesh position={[6, 3.7 + 0.35 * pump.inlet, 0]} material={M.chrome} castShadow><sphereGeometry args={[0.2, 20, 14]} /></mesh>
      <mesh position={[6, 3.9, 1.05 + 0.3 * pump.outlet]} material={M.chrome} castShadow><sphereGeometry args={[0.17, 20, 14]} /></mesh>
      <PipeFlow points={SUC} radius={0.2} cut={cut.tank} shell="glass" flow={pump.inlet} phase={pump.sucPhase} count={14} seed={2} />
      <PipeFlow points={OUTC} radius={0.24} cut={cut.pump} shell="steel" flow={pump.outlet} phase={pump.disPhase} count={8} seed={4} />
      <PipeFlow points={RISER} radius={0.24} cut={Math.max(cut.pump, cut.valve)} shell="steel" flow={flowOut} phase={hosePh * 4} count={14} seed={6} />
      <mesh position={[6, 3.9, 1.5]} material={M.steel} castShadow><sphereGeometry args={[0.32, 18, 12]} /></mesh>
      {/* gauge */}
      <mesh position={[6, 5.8, 1.95]} rotation={[Math.PI / 2, 0, 0]} material={M.steel}><cylinderGeometry args={[0.12, 0.12, 0.9, 12]} /></mesh>
      <Gauge p={s.P} position={[6, 5.8, 2.4]} scale={1.0} />
      {/* release (needle) valve */}
      <PipeFlow points={TEE} radius={0.2} cut={cut.valve} shell="steel" flow={valve} phase={-hosePh * 2} count={8} seed={7} />
      <mesh position={[7.8, 4.6, 1.5]} rotation={[0, 0, Math.PI / 2]} material={valveMat} castShadow renderOrder={3}><cylinderGeometry args={[0.42, 0.42, 1.2, 28, 1, true]} /></mesh>
      <mesh position={[8.4, 4.6, 1.5]} rotation={[0, 0, Math.PI / 2]} material={M.brass} castShadow><cylinderGeometry args={[0.46, 0.46, 0.3, 6]} /></mesh>
      <mesh position={[7.55, 4.6, 1.5]} rotation={[0, Math.PI / 2, 0]} material={M.darkSteel} side={THREE.DoubleSide}><ringGeometry args={[0.14, 0.4, 28]} /></mesh>
      <mesh position={[xN, 4.6, 1.5]} rotation={[0, 0, Math.PI / 2]} material={M.red} castShadow><coneGeometry args={[0.2, 0.6, 20]} /></mesh>
      <mesh position={[(xN + 0.3 + xW) / 2, 4.6, 1.5]} rotation={[0, 0, Math.PI / 2]} material={M.chrome} castShadow><cylinderGeometry args={[0.09, 0.09, xW - xN - 0.3, 12]} /></mesh>
      <group position={[xW, 4.6, 1.5]} rotation={[valve * Math.PI * 6, 0, 0]}>
        <mesh rotation={[0, Math.PI / 2, 0]} material={M.yellow} castShadow><torusGeometry args={[0.55, 0.09, 10, 28]} /></mesh>
        <mesh material={M.yellow}><boxGeometry args={[0.1, 1.1, 0.1]} /></mesh>
        <mesh material={M.yellow}><boxGeometry args={[0.1, 0.1, 1.1]} /></mesh>
        <mesh rotation={[0, 0, Math.PI / 2]} material={M.darkSteel}><cylinderGeometry args={[0.16, 0.16, 0.25, 16]} /></mesh>
      </group>
      <PipeFlow points={RET} radius={0.2} cut={Math.max(cut.valve, cut.tank)} shell="steel" flow={valve} phase={s.phase.ret} count={10} seed={8} />
      {/* hand lever */}
      <mesh position={[LEVER.px, 4.5, 0]} material={M.paintDark} castShadow><boxGeometry args={[0.5, 3.4, 0.45]} /></mesh>
      {[-0.32, 0.32].map((z) => <mesh key={z} position={[LEVER.px, LEVER.py, z]} material={M.darkSteel}><boxGeometry args={[0.7, 1.0, 0.1]} /></mesh>)}
      <mesh position={[LEVER.px, LEVER.py, 0]} rotation={[Math.PI / 2, 0, 0]} material={M.chrome}><cylinderGeometry args={[0.15, 0.15, 0.9, 14]} /></mesh>
      <group position={[LEVER.px, LEVER.py, 0]} rotation={[0, 0, -pump.theta]}>
        <mesh position={[1.35, 0, 0]} material={M.paint} castShadow><boxGeometry args={[7.5, 0.3, 0.45]} /></mesh>
        <mesh position={[3.9, 0, 0]} rotation={[0, 0, Math.PI / 2]} material={M.yellow} castShadow><cylinderGeometry args={[0.26, 0.26, 2.2, 20]} /></mesh>
      </group>
    </group>
  );
};

/** The complete machine. */
export const PressMachine: React.FC<{s: State}> = ({s}) => {
  return (
    <group>
      <Frame />
      <Workpiece c={s.work} />
      <Plate y={s.plateBottom} />
      <HydraulicCylinder s={s} plateBottom={s.plateBottom} />
      <PumpUnit s={s} />
      <PipeFlow points={HOSE_POINTS} radius={0.2} cut={s.cut.hose} shell="rubber" flow={s.hoseFlow} phase={s.phase.hose} count={56} seed={12} />
      <Burst t={s.t} t0={46.6} dur={1.4} center={[0, BED_Y + 0.2, 0]} count={36} speed={3.4} size={0.1} seed={21} />
      <Burst t={s.t} t0={49.5} dur={1.2} center={[0, BED_Y + 0.3, 0]} count={24} speed={2.8} size={0.09} seed={22} />
      <Burst t={s.t} t0={51.3} dur={1.2} center={[0, BED_Y + 0.3, 0]} count={24} speed={3.0} size={0.09} seed={23} />
    </group>
  );
};
