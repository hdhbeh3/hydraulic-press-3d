import * as THREE from 'three';
import {mulberry32} from './math';

type Draw = (g: CanvasRenderingContext2D, w: number, h: number, r: () => number) => void;
function canvasTex(w: number, h: number, seed: number, draw: Draw, rx: number, ry: number) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  const g = c.getContext('2d')!;
  draw(g, w, h, mulberry32(seed)); // seeded => identical on every render worker
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(rx, ry);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}
const speckle = (g: CanvasRenderingContext2D, w: number, h: number, r: () => number, n: number, a: number) => {
  for (let i = 0; i < n; i++) {
    const v = Math.floor(r() * 255);
    g.fillStyle = `rgba(${v},${v},${v},${a})`;
    g.fillRect(r() * w, r() * h, 1 + r() * 2, 1 + r() * 2);
  }
};

let cache: ReturnType<typeof build> | null = null;
export const getMats = () => (cache ??= build());

function build() {
  const std = (o: THREE.MeshStandardMaterialParameters) => new THREE.MeshStandardMaterial(o);
  const phys = (o: THREE.MeshPhysicalMaterialParameters) => new THREE.MeshPhysicalMaterial(o);

  const brickTex = canvasTex(512, 512, 11, (g, w, h, r) => {
    g.fillStyle = '#b4ad9f'; g.fillRect(0, 0, w, h);
    const pal = ['#8a4a3a', '#7d4033', '#94503f', '#6f3a2e', '#9b5b46', '#84463a'];
    for (let row = 0; row < 16; row++)
      for (let i = -1; i < 8; i++) {
        g.fillStyle = pal[Math.floor(r() * pal.length)];
        g.fillRect(i * 64 + (row % 2) * 32 + 2, row * 32 + 2, 60, 28);
      }
    speckle(g, w, h, r, 2500, 0.12);
  }, 14, 3);
  const grassTex = canvasTex(512, 512, 21, (g, w, h, r) => {
    g.fillStyle = '#4c6b32'; g.fillRect(0, 0, w, h);
    for (let i = 0; i < 9000; i++) {
      const gr = 80 + Math.floor(r() * 70);
      g.fillStyle = `rgb(${40 + r() * 40},${gr},${25 + r() * 30})`;
      g.fillRect(r() * w, r() * h, 2, 3 + r() * 4);
    }
  }, 60, 60);
  const woodTex = canvasTex(512, 512, 31, (g, w, h, r) => {
    for (let s = 0; s < 8; s++) {
      g.fillStyle = `rgb(${150 + r() * 25},${100 + r() * 20},${62 + r() * 15})`;
      g.fillRect(0, s * 64, w, 64);
      for (let i = 0; i < 40; i++) {
        g.strokeStyle = `rgba(70,40,20,${0.05 + r() * 0.12})`;
        g.beginPath(); const y = s * 64 + r() * 64; g.moveTo(0, y); g.bezierCurveTo(w * 0.3, y + r() * 4 - 2, w * 0.6, y + r() * 4 - 2, w, y + r() * 3 - 1.5); g.stroke();
      }
      g.fillStyle = 'rgba(25,15,8,0.55)'; g.fillRect(0, s * 64, w, 2);
    }
  }, 4, 1);
  const concreteTex = canvasTex(512, 512, 41, (g, w, h, r) => {
    g.fillStyle = '#8b8a86'; g.fillRect(0, 0, w, h);
    speckle(g, w, h, r, 9000, 0.1);
    g.strokeStyle = 'rgba(30,30,30,0.35)'; g.lineWidth = 3; g.strokeRect(0, 0, w, h);
  }, 6, 3);

  const oil = phys({color: '#1f80ff', transparent: true, opacity: 0.72, roughness: 0.08, metalness: 0, emissive: '#0a49cf', emissiveIntensity: 0.4, clearcoat: 0.6});
  const glass = phys({color: '#ffffff', transparent: true, opacity: 0.14, roughness: 0.04, metalness: 0, clearcoat: 1, clearcoatRoughness: 0.05, depthWrite: false, envMapIntensity: 1.6});

  return {
    oil, glass,
    steel: std({color: '#9aa2a9', metalness: 0.9, roughness: 0.34}),
    darkSteel: std({color: '#3d434a', metalness: 0.8, roughness: 0.45}),
    chrome: std({color: '#d9dde0', metalness: 1, roughness: 0.12}),
    machined: std({color: '#b8bec3', metalness: 0.95, roughness: 0.22}),
    billet: std({color: '#a7aeb4', metalness: 0.85, roughness: 0.42}),
    paint: std({color: '#1b7a84', metalness: 0.35, roughness: 0.5}),
    paintDark: std({color: '#14565e', metalness: 0.35, roughness: 0.55}),
    yellow: std({color: '#f2b400', metalness: 0.2, roughness: 0.5}),
    rubber: std({color: '#17191c', metalness: 0, roughness: 0.8}),
    dark: std({color: '#0e0f11', metalness: 0.2, roughness: 0.6}),
    brass: std({color: '#c79a3a', metalness: 0.95, roughness: 0.3}),
    red: std({color: '#d1342c', metalness: 0.1, roughness: 0.5}),
    gaugeFace: std({color: '#f4f2ea', roughness: 0.7}),
    needle: std({color: '#e53b2e', roughness: 0.4}),
    capBlue: std({color: '#2563eb', roughness: 0.45}),
    iron: std({color: '#2c2f33', metalness: 0.7, roughness: 0.55}),
    wood: std({map: woodTex, roughness: 0.75}),
    woodDark: std({color: '#6a4a30', roughness: 0.8}),
    brick: std({map: brickTex, roughness: 0.95}),
    grass: std({map: grassTex, roughness: 1}),
    concrete: std({map: concreteTex, roughness: 0.95}),
    stone: std({color: '#cfc8b8', roughness: 0.9}),
    windowGlass: std({color: '#1c2a3a', metalness: 0.9, roughness: 0.08}),
    hedge: std({color: '#2f5a2a', roughness: 1}),
    flow: new THREE.MeshBasicMaterial({color: '#aeeeff', transparent: true, opacity: 0.95, toneMapped: false}),
    dust: new THREE.MeshStandardMaterial({color: '#bdb8ad', roughness: 1, transparent: true, opacity: 0.8}),
  };
}
export type Mats = ReturnType<typeof build>;
